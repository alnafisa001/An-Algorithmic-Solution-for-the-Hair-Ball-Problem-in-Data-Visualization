# ================ Packages ================

# For a Network Analysis and Visualization
# https://cran.r-project.org/web/packages/igraph/index.html
install.packages("igraph", dependencies=TRUE)
library(igraph)

# Tools to create and modify network objects. The network class can represent a range of relational data types, and supports arbitrary vertex/edge/graph attributes.
# https://cran.r-project.org/web/packages/network/index.html
install.packages("network")
library(network)

# Calculates a variety of indices and values for a bipartite network 
# http://www.inside-r.org/packages/cran/bipartite/docs/.networklevel
install.packages("bipartite")
library(bipartite)

# A range of tools for social network analysis, including node and graph-level indices, structural distance and covariance methods, structural equivalence detection, network regression, random graph generation, and 2D/3D network visualization.
# https://cran.r-project.org/web/packages/sna/index.html
install.packages("sna")
library(sna)

# Construct visualizations such as timelines and animated movies of networkDynamic objects to show changes in structure and attributes over time.
# https://cran.r-project.org/web/packages/ndtv/ndtv.pdf
install.packages("ndtv")
library(ndtv)

# For a sequence of font family names, return the first one installed on the system.
# https://cran.r-project.org/web/packages/extrafont/extrafont.pdf
install.packages("extrafont")
library(extrafont)

# To analysis of bipartite graphs and their monopartite projections
# http://crantastic.org/packages/biGraph
install.packages("biGraph")
library(biGraph)

# Build, Import and Export GEXF Graph Files
# https://cran.r-project.org/web/packages/rgexf/index.html
install.packages("rgexf", dependencies=TRUE)
library(rgexf)

# Tools for Parsing and Generating XML Within R and S-Plus
# https://cran.r-project.org/web/packages/XML/index.html
install.packages("XML", dependencies=TRUE)
library(XML)

# Simple Animated Plots For R
# https://cran.r-project.org/web/packages/anim.plots/index.html
install.packages("anim.plots", dependencies=TRUE)
library(anim.plots)

# linkcomm provides tools for the generation, visualization, and analysis of link communities in networks of arbitrary size and type.
# https://cran.r-project.org/web/packages/linkcomm/index.html
install.packages("linkcomm")
library(linkcomm)

# Simulate Bipartite Graphs with Fixed Marginals Through Sequential Importance Sampling.
# https://cran.r-project.org/web/packages/networksis/index.html
install.packages("networksis")
library("networksis")

# ================ Read the data and plot ================

setwd('C:/Users/Sony/Desktop')
SmallDatasets4<- read.csv("Five Bipartite K2, 3 in One Bipartite K2, 3.csv", header=T, as.is=T)
SmallDatasets4

#Runtime
start.time <- Sys.time()

attach(SmallDatasets4)
x
y 
# Igrap1
igraph1 <- graph.data.frame(SmallDatasets4)
igraph1
V(igraph1)$type <- V(igraph1)$name %in% SmallDatasets4[,1]
bipartite_mapping(igraph1)
lc <- getLinkCommunities(SmallDatasets4, hcmethod = "single")

#  ================ Loop-Five K2,3 Bipartite ================

for(igraph in data.frame(SmallDatasets4)){ 
 if (
lc <- largest.cliques(igraph1)
lc
# use spinglass algo to detect community
sgc <- spinglass.community(igraph1)
sgc 
sgc[[1]]
g1 <- subgraph(igraph1, sgc[[1]])
g1
sgc[[2]]
g2 <- subgraph(igraph1, sgc[[2]])
g2
sgc[[3]]
g3 <- subgraph(igraph1, sgc[[3]])
g3
sgc[[4]]
g4 <- subgraph(igraph1, sgc[[4]])
g4
sgc[[5]]
g5 <- subgraph(igraph1, sgc[[5]])
g5

# K2,3 Bipartite 1
data.frame(SmallDatasets4)
c1 = x[c(1,2,3,4,5,6)]
n1 = unique(c1)
c2 = y[c(1,2,3,4,5,6)]
n2 = unique(c2)
b1 = capture.output(cat(n1,n2))
cat(b1,"\n")

# K2,3 Bipartite 2
data.frame(SmallDatasets4)
c3 = x[c(7,8,9,10,11,12)]
n3 = unique(c3)
c4 = y[c(7,8,9,10,11,12)]
n4 = unique(c4)
b2 = capture.output(cat(n3,n4))
cat(b2,"\n")

# K2,3 Bipartite 3
data.frame(SmallDatasets4)
c5 = x[c(13,14,15,16,17,18)]
n5 = unique(c5)
c6 = y[c(13,14,15,16,17,18)]
n6 = unique(c6)
b3 = capture.output(cat(n5,n6))
cat(b3,"\n")

# K2,3 Bipartite 4
data.frame(SmallDatasets4)
c7 = x[c(19,20,21,22,23,24)]
n7 = unique(c7)
c8 = y[c(19,20,21,22,23,24)]
n8 = unique(c8)
b4 = capture.output(cat(n7,n8))
cat(b4,"\n")

# K2,3 Bipartite 5
data.frame(SmallDatasets4)
c9 = x[c(25,26,27,28,29,30)]
n9 = unique(c9)
c10 = y[c(25,26,27,28,29,30)]
n10 = unique(c10)
b5 = capture.output(cat(n9,n10))
cat(b5,"\n")

# K2,3 Bipartite Between All
data.frame(SmallDatasets4)
c11 = x[c(31,32,33,34,35,36)]
n11 = unique(c11)
c12 = y[c(31,32,33,34,35,36)]
n12 = unique(c12)
bBA = capture.output(cat(n11,n12))
cat(bBA,"\n")

AllBipartiteK23 = capture.output(cat(n1,n2,n3,n4,n5,n6,n7,n8,n9,n10,n11,n12))
AllBipartiteK23
cat(AllBipartiteK23,"\n")
lc <- largest.cliques(igraph1)
lc
sgc <- spinglass.community(igraph1)
sgc 

#  ================ First Layouts ================

{
    print(
# Random layout
plot(igraph1, layout=layout.random, main="Random Layout")

#bipartite layout
lc <- getLinkCommunities(SmallDatasets4, hcmethod = "single")

# fruchterman.reingold.layout(tree layout) 
V(igraph1)$frame.color <- "white"
V(igraph1)$color = "orange"
V(igraph1)$size = 13
E(igraph1)$arrow.mode = 0
plot(igraph1, layout=layout.fruchterman.reingold, main="Tree layout (Five K2, 3 in one K2, 3 Bipartite)")
  )
#end.time <- Sys.time()
#time.taken <- end.time - start.time
3time.taken

#  ================ Frist Compress K2,3 Bipartite ================

 ifelse(

#Runtime
#start.time <- Sys.time()

Compress1 <- data.frame(SmallDatasets4)
Compress1 
attach(Compress1)
Compress1$x[1:3]= c("B1")
Compress1$x[4:6]= c("B2")
Compress1$x[7:36]= c("B1")
#Compress1$x[19:24]= c("B2")
#Compress1$x[25:30]= c("B2")
#Compress1$x[31:36]= c("B2")
attach(Compress1)
x
Compress1$y[1:1]= c("B3")
Compress1$y[2:2]= c("B4")
Compress1$y[3:3]= c("B5")
Compress1$y[4:4]= c("B3")
Compress1$y[5:5]= c("B4")
Compress1$y[6:6]= c("B5")
#Compress1$y[7:7]= c("B3")
#Compress1$y[8:8]= c("B4")
#Compress1$y[9:9]= c("B5")
Compress1$y[7:36]= c("B1")
attach(Compress1)
y
attach(Compress1)
Compress1 
write.csv(Compress1, file = "MyData.csv",row.names=FALSE)
CompressBipartite1<- read.csv("MyData.csv", header=T, as.is=T)
CompressBipartite1

igraph2 <- graph.data.frame(CompressBipartite1)
igraph2
V(igraph2)$type <- V(igraph2)$name %in% Compress1[,1]
bipartite.projection(igraph2)
bipartite_mapping(igraph2)
lc <- largest.cliques(igraph2)
lc
sgc <- spinglass.community(igraph2)
sgc 

#  ================ Second Layouts ================

{
  print(
# Bipartite K2, 3 Package 
lc <- getLinkCommunities(CompressBipartite1, hcmethod = "single")
plot(igraph2, layout=layout.bipartite, mark.groups=list(c("B1"),c("B2"),c("B3"),c("B4"),c("B5")),mark.col=c("green","red", "yellow", "blue", "orange"),main="Bipartite K2, 3 Layout")
legend(x=-1.5, y=-1.1, c("K2,3 Bipartite-1"), pch=21, col="#777777", pt.cex=2, cex=.8, bty="n", ncol=1, pt.bg="green")
legend(x=-1.5, y=-1.2, c("K2,3 Bipartite-2"), pch=21, col="#777777", pt.cex=2, cex=.8, bty="n", ncol=1, pt.bg="red")
legend(x=-1.5, y=-1.3, c("K2,3 Bipartite-3"), pch=21, col="#777777", pt.cex=2, cex=.8, bty="n", ncol=1, pt.bg="yellow")
legend(x=-1.5, y=-1.4, c("K2,3 Bipartite-4"), pch=21, col="#777777", pt.cex=2, cex=.8, bty="n", ncol=1, pt.bg="blue")
legend(x=-1.5, y=-1.5, c("K2,3 Bipartite-5"), pch=21, col="#777777", pt.cex=2, cex=.8, bty="n", ncol=1, pt.bg="orange")

# Fruchterman.reingold.layout(tree layout) 
V(igraph1)$frame.color <- "white"
V(igraph1)$color = "orange"
V(igraph1)$size = 13
E(igraph1)$arrow.mode = 0
plot(igraph2, layout=layout.fruchterman.reingold, mark.groups=list(c("B1"),c("B2"),c("B3"),c("B4"),c("B5")),mark.col=c("green","red", "yellow", "blue", "orange"),main="Tree layout (Five K2, 3 in one K2, 3 Bipartite)")
legend(x=-1.5, y=-1.1, c("K2,3 Bipartite-1"), pch=21, col="#777777", pt.cex=2, cex=.8, bty="n", ncol=1, pt.bg="green")
legend(x=-1.5, y=-1.2, c("K2,3 Bipartite-2"), pch=21, col="#777777", pt.cex=2, cex=.8, bty="n", ncol=1, pt.bg="red")
legend(x=-1.5, y=-1.3, c("K2,3 Bipartite-3"), pch=21, col="#777777", pt.cex=2, cex=.8, bty="n", ncol=1, pt.bg="yellow")
legend(x=-1.5, y=-1.4, c("K2,3 Bipartite-4"), pch=21, col="#777777", pt.cex=2, cex=.8, bty="n", ncol=1, pt.bg="blue")
legend(x=-1.5, y=-1.5, c("K2,3 Bipartite-5"), pch=21, col="#777777", pt.cex=2, cex=.8, bty="n", ncol=1, pt.bg="orange")

 )

#  ================ Second Compress K2,3 Bipartite ================
 
 ifelse (
Compress2 <- data.frame(SmallDatasets4)
Compress2 
attach(Compress2)
Compress2$x[1:36]= c("All")
attach(Compress2)
x
Compress2$y[1:36]=c("All")
attach(Compress2)
y
attach(Compress2)
Compress2 
write.csv(Compress2, file = "MyData.csv",row.names=FALSE)
CompressBipartite2<- read.csv("MyData.csv", header=T, as.is=T)
CompressBipartite2

igraph3 <- graph.data.frame(CompressBipartite2)
igraph3
V(igraph3)$type <- V(igraph3)$name %in% Compress2[,1]
bipartite.projection(igraph3)
bipartite_mapping(igraph3)

#  ================ Third Layouts ================

#bipartite Package 
plot(igraph3,vertex.size=15, layout=layout.bipartite, mark.groups=c("All"),mark.col="#FFFF00", layout=layout.circle, vertex.label=V(igraph3)$media, vertex.label.cex=.7,  main="Bipartite K2, 3 Layout") 
legend(x=-1.5, y=-1.1, c("K2,3 Bipartite-All"), pch=21,
       col="#777777", pt.cex=2, cex=.8, bty="n", ncol=1, pt.bg="#FFFF00")

# Fruchterman.reingold.layout(tree layout) 
V(igraph3)$frame.color <- "white"
V(igraph3)$color = "orange"
V(igraph3)$size = 13
E(igraph3)$arrow.mode = 0
plot(igraph3, layout=layout.fruchterman.reingold, main="Tree layout (Five K2, 3 in one K2, 3 Bipartite)",mark.groups=c("All"),mark.col="#FFFF00")
legend(x=-1.5, y=-1.1, c("K2,3 Bipartite-All"), pch=21,
       col="#777777", pt.cex=2, cex=.8, bty="n", ncol=1, pt.bg="#FFFF00")

      )
   }
}

#end.time <- Sys.time()
#time.taken <- end.time - start.time
#time.taken

#  ================ Change the position of the node ================

#Runtime
#start.time <- Sys.time()

V(igraph3)$size <- 20
par(mar = c(14,13,0.0,0.0))
plot(igraph3, layout=layout.random, mark.groups=c("All"),mark.col="#FFFF00")

#  ================ Represent these K2, 3 ================

end.time <- Sys.time()
time.taken <- end.time - start.time
time.taken


