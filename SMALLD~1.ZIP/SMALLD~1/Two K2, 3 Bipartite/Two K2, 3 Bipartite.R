# ================ Packages ================

# For a Network Analysis and Visualization
# https://cran.r-project.org/web/packages/igraph/index.html
install.packages("igraph", dependencies=TRUE)
library(igraph)

# Tools to create and modify network objects. The network class can represent a range of relational data types, and supports arbitrary vertex/edge/graph attributes.
# https://cran.r-project.org/web/packages/network/index.html
install.packages("network")
library(network)

# Calculates a variety of indices and values for a bipartite network 
# http://www.inside-r.org/packages/cran/bipartite/docs/.networklevel
install.packages("bipartite")
library(bipartite)

# A range of tools for social network analysis, including node and graph-level indices, structural distance and covariance methods, structural equivalence detection, network regression, random graph generation, and 2D/3D network visualization.
# https://cran.r-project.org/web/packages/sna/index.html
install.packages("sna")
library(sna)

# Construct visualizations such as timelines and animated movies of networkDynamic objects to show
changes in structure and attributes over time.
# https://cran.r-project.org/web/packages/ndtv/ndtv.pdf
install.packages("ndtv")
library(ndtv)

# For a sequence of font family names, return the first one installed on the system.
# https://cran.r-project.org/web/packages/extrafont/extrafont.pdf
install.packages("extrafont")
library(extrafont)

# To analysis of bipartite graphs and their monopartite projections
# http://crantastic.org/packages/biGraph
install.packages("biGraph")
library(biGraph)

# Build, Import and Export GEXF Graph Files
# https://cran.r-project.org/web/packages/rgexf/index.html
install.packages("rgexf", dependencies=TRUE)
library(rgexf)

# Tools for Parsing and Generating XML Within R and S-Plus
# https://cran.r-project.org/web/packages/XML/index.html
install.packages("XML", dependencies=TRUE)
library(XML)

# Simple Animated Plots For R
# https://cran.r-project.org/web/packages/anim.plots/index.html
install.packages("anim.plots", dependencies=TRUE)
library(anim.plots)

# linkcomm provides tools for the generation, visualization, and analysis of link communities in networks of arbitrary size and type.
# https://cran.r-project.org/web/packages/linkcomm/index.html
install.packages("linkcomm")
library(linkcomm)

# Simulate Bipartite Graphs with Fixed Marginals Through Sequential Importance Sampling.
# https://cran.r-project.org/web/packages/networksis/index.html
install.packages("networksis")
library("networksis")

# ================ Read the data and plot ================

setwd('C:/Users/Sony/Desktop')
SmallDatasets3<- read.csv("Two K2, 3 Bipartite.csv", header=T, as.is=T)
SmallDatasets3

#Runtime
start.time <- Sys.time()

attach(SmallDatasets3)
x
y 
# Igraph3
for(igraph in data.frame(SmallDatasets3)){ 
 if ( 
igraph1 <- graph.data.frame(SmallDatasets3)
igraph1
relations<-as.matrix(SmallDatasets3)
network.edgecount(nrelations)
nrelations<-network(relations,anage=T)
nrelations
V(igraph1)$type <- V(igraph1)$name %in% SmallDatasets3[,1]
bipartite_mapping(igraph1)
lc <- getLinkCommunities(SmallDatasets3, hcmethod = "single")
sc <- spinglass.community(lc )
sc

#  ================ Two K2,3 Bipartite ================

lc <- largest.cliques(igraph1)
lc
# K2,3 Bipartite 1
data.frame(SmallDatasets3)
c1 = x[c(1,2,3,4,5,6)]
n1 = unique(c1)
c2 = y[c(1,2,3,4,5,6)]
n2 = unique(c2)
b1 = capture.output(cat(n1,n2))
cat(b1,"\n")

# K2,3 Bipartite 2
data.frame(SmallDatasets3)
c3 = x[c(10,11,12,13,14,15)]
n3 = unique(c3)
c4 = y[c(10,11,12,13,14,15)]
n4 = unique(c4)
b2 = capture.output(cat(n3,n4))
cat(b2,"\n")

AllBipartiteK23 = capture.output(cat(n1,n2,n3,n4))
AllBipartiteK23
cat(AllBipartiteK23,"\n")
 )

#  ================ First Layouts ================

print(
# Random layout
plot(igraph1, layout=layout.random, main="Random Layout")

# Bipartite Package
lc <- getLinkCommunities(SmallDatasets3, hcmethod = "single")
plot(igraph1, vertex.size=15, layout=layout.bipartite, vertex.label=V(igraph1)$media, vertex.label.cex=.7, main="Two Bipartite K2, 3") 

# Fruchterman.reingold.layout(Tree layout) 
V(igraph1)$frame.color <- "white"
V(igraph1)$color = "orange"
V(igraph1)$size = 13
E(igraph1)$arrow.mode = 0
plot(igraph1, layout=layout.fruchterman.reingold, main="Tree layout (Two K2, 3 Bipartite)")

end.time <- Sys.time()
time.taken <- end.time - start.time
time.taken

)

#  ================ Compress K2,3 Bipartite ================

else(
#Runtime
#start.time <- Sys.time()

Compress1 <- data.frame(SmallDatasets3)
Compress1 
attach(Compress1)
Compress1$x[1:6]= c("B1")
Compress1$x[10:15]= c("B2")
attach(Compress1)
x
Compress1$y[1:6]=c("B1")
Compress1$y[10:15]=c("B2")
attach(Compress1)
y
attach(Compress1)
Compress1 
write.csv(Compress1, file = "MyData.csv",row.names=FALSE)
CompressBipartite1<- read.csv("MyData.csv", header=T, as.is=T)
CompressBipartite1

igraph2 <- graph.data.frame(CompressBipartite1)
igraph2
V(igraph2)$type <- V(igraph2)$name %in% CompressBipartite1[,1]
bipartite.projection(igraph2)
bipartite_mapping(igraph2)
)

#  ================ Second Layouts ================

print(
# Bipartite package
lc <- getLinkCommunities(CompressBipartite1, hcmethod = "single")
plot(igraph2,vertex.size=15, layout=layout.bipartite,  mark.groups=list(c("B1"),c("B2")),mark.col=c("green","red"), vertex.label=V(igraph2)$media, vertex.label.cex=.7,  main="No Bipartite K2, 3") 
legend(x=-1.5, y=-1.1, c("K2,3 Bipartite-1"), pch=21,
       col="#777777", pt.cex=2, cex=.8, bty="n", ncol=1, pt.bg="green")
legend(x=-1.5, y=-1.2, c("K2,3 Bipartite-2"), pch=21,
       col="#777777", pt.cex=2, cex=.8, bty="n", ncol=1, pt.bg="red")

# fruchterman.reingold.layout(Tree layout) 
V(igraph2)$frame.color <- "white"
V(igraph2)$color = "orange"
V(igraph2)$size = 13
E(igraph2)$arrow.mode = 0
plot(igraph2, layout=layout.fruchterman.reingold,mark.groups=list(c("B1"),c("B2")),mark.col=c("green","red"), main="Tree layout (Two K2, 3 Bipartite)")
legend(x=-1.5, y=-1.1, c("K2,3 Bipartite-1"), pch=21,col="#777777", pt.cex=2, cex=.8, bty="n", ncol=1, pt.bg="green")
legend(x=-1.5, y=-1.2, c("K2,3 Bipartite-2"), pch=21,col="#777777", pt.cex=2, cex=.8, bty="n", ncol=1, pt.bg="red")

 )
}
end.time <- Sys.time()
time.taken <- end.time - start.time
time.taken