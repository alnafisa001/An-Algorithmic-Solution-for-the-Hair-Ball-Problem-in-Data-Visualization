# ================ Packages ================

#For a Network Analysis and Visualization
#https://cran.r-project.org/web/packages/igraph/index.html
install.packages("igraph", dependencies=TRUE)
library(igraph)

#Tools to create and modify network objects. The network class can represent a range of relational data types, and supports arbitrary vertex/edge/graph attributes.
#https://cran.r-project.org/web/packages/network/index.html
install.packages("network")
library(network)

#Calculates a variety of indices and values for a bipartite network 
#http://www.inside-r.org/packages/cran/bipartite/docs/.networklevel
install.packages("bipartite")
library(bipartite)

#A range of tools for social network analysis, including node and graph-level indices, structural distance and covariance methods, structural equivalence detection, network regression, random graph generation, and 2D/3D network visualization.
#https://cran.r-project.org/web/packages/sna/index.html
install.packages("sna")
library(sna)

#Construct visualizations such as timelines and animated movies of networkDynamic objects to show
changes in structure and attributes over time.
#https://cran.r-project.org/web/packages/ndtv/ndtv.pdf
install.packages("ndtv")
library(ndtv)

#For a sequence of font family names, return the first one installed on the system.
#https://cran.r-project.org/web/packages/extrafont/extrafont.pdf
install.packages("extrafont")
library(extrafont)

#To analysis of bipartite graphs and their monopartite projections
#http://crantastic.org/packages/biGraph
install.packages("biGraph")
library(biGraph)

#Build, Import and Export GEXF Graph Files
#https://cran.r-project.org/web/packages/rgexf/index.html
install.packages("rgexf", dependencies=TRUE)
library(rgexf)

#Tools for Parsing and Generating XML Within R and S-Plus
#https://cran.r-project.org/web/packages/XML/index.html
install.packages("XML", dependencies=TRUE)
library(XML)

#Simple Animated Plots For R
#https://cran.r-project.org/web/packages/anim.plots/index.html
install.packages("anim.plots", dependencies=TRUE)
library(anim.plots)

#linkcomm provides tools for the generation, visualization, and analysis of link communities in networks of arbitrary size and type.
#https://cran.r-project.org/web/packages/linkcomm/index.html
install.packages("linkcomm")
library(linkcomm)

# Simulate Bipartite Graphs with Fixed Marginals Through Sequential Importance Sampling.
# https://cran.r-project.org/web/packages/networksis/index.html
install.packages("networksis")
library("networksis")

# ================ Read the data ================

setwd('C:/Users/Sony/Desktop')
Time_Use<- read.csv("Time_Use.csv", header=T, as.is=T)
Time_Use

#Runtime
start.time <- Sys.time()

attach(Time_Use)
SEX
GEOACL00
Total
PersonalCare
Sleep 
Eating 
Study 
SchoolAndUniversityExceptHomework 
Homework 
FreeTimeStudy 
HouseholdAndFamilyCare 
DishWashing
CleaningDwelling 
HouseholdUpkeepExceptCleaningDwelling 
Laundry 
Ironing 
HandicraftAndProducingTextilesAndOtherCareForTextiles 
GardeningOtherPetCare 
CaringForPets 
WalkingTheDog 
ConstructionAndRepairs 
ShoppingAndServices 
ChildcareExceptTeachingReadingAndTalking 
TeachingReadingAndTalkingWithChild 
HouseholdManagementAndHelpFamilyMember 
VisitingAndFeasts 
EntertainmentAndCulture 
Resting 
WalkingAndHiking 
SportsAndOutdoorActivitiesExceptWalkingAndHiking
Computing 
HobbiesAndGamesExceptComputingAndComputerGames
ReadingBooks 
TVAndVideo 
RadioAndMusic 
UnspecifiedLeisure 
TravelToFromWork 
TravelRelatedToStudy 
TravelRelatedToShoppingAndServices
TransportingAChild 

for(igraph in data.frame(Time_Use)){ 
if (
relations<-as.matrix(Time_Use)
network.edgecount(relations)
nrelations<-network(relations,Time_Use=T)
nrelations
nv <- nrow(Time_Use)
nv 
net <- network.initialize(nv)
net 
# Data frame of edges
igraph <- graph.data.frame(Time_Use)
igraph
V(igraph)$type <- V(igraph)$name %in% Time_Use[,1]
bipartite_mapping(igraph)
lc <- getLinkCommunities(Time_Use, hcmethod = "single")
sc <- spinglass.community(igraph)
sc

# Randomly layout
V(igraph)$frame.color <- "white"
V(igraph)$color = "orange"
V(igraph)$size = 11
E(igraph)$arrow.mode = 0
plot(igraph, layout=layout.random, main="Random Layout",vertex.label.cex=.4)

PersonalCare <- cbind(Time_Use$GEOACL00,Time_Use$PersonalCare)
Sleep <- cbind(Time_Use$GEOACL00,Time_Use$Sleep)
Eating <- cbind(Time_Use$GEOACL00,Time_Use$Eating)
EmploymentRelatedActivitiesAndTravelAsPartOfDuringMainAndSecondJob <- cbind(Time_Use$GEOACL00,Time_Use$EmploymentRelatedActivitiesAndTravelAsPartOfDuringMainAndSecondJob)
MainAndSecondJobAndRelatedTravel <- cbind(Time_Use$GEOACL00,Time_Use$MainAndSecondJobAndRelatedTravel)
ActivitiesRelatedToEmploymentAndUnspecifiedEmployment <- cbind(Time_Use$GEOACL00,Time_Use$ActivitiesRelatedToEmploymentAndUnspecifiedEmployment)
Study <- cbind(Time_Use$GEOACL00,Time_Use$Study)
SchoolAndUniversityExceptHomework <- cbind(Time_Use$GEOACL00,Time_Use$SchoolAndUniversityExceptHomework)
Homework <- cbind(Time_Use$GEOACL00,Time_Use$Homework)
FreeTimeStudy <- cbind(Time_Use$GEOACL00,Time_Use$FreeTimeStudy)
HouseholdAndFamilyCare <- cbind(Time_Use$GEOACL00,Time_Use$HouseholdAndFamilyCare)
FoodManagementExceptDishWashing <- cbind(Time_Use$GEOACL00,Time_Use$FoodManagementExceptDishWashing)
DishWashing <- cbind(Time_Use$GEOACL00,Time_Use$DishWashing)
CleaningDwelling <- cbind(Time_Use$GEOACL00,Time_Use$CleaningDwelling)
HouseholdUpkeepExceptCleaningDwelling <- cbind(Time_Use$GEOACL00,Time_Use$HouseholdUpkeepExceptCleaningDwelling)
Laundry <- cbind(Time_Use$GEOACL00,Time_Use$Laundry)
Ironing <- cbind(Time_Use$GEOACL00,Time_Use$Ironing)
HandicraftAndProducingTextilesAndOtherCareForTextiles <- cbind(Time_Use$GEOACL00,Time_Use$HandicraftAndProducingTextilesAndOtherCareForTextiles)
GardeningOtherPetCare <- cbind(Time_Use$GEOACL00,Time_Use$GardeningOtherPetCare)
TendingDomesticAnimals <- cbind(Time_Use$GEOACL00,Time_Use$TendingDomesticAnimals)
CaringForPets <- cbind(Time_Use$GEOACL00,Time_Use$CaringForPets)
WalkingTheDog <- cbind(Time_Use$GEOACL00,Time_Use$WalkingTheDog)
ConstructionAndRepairs <- cbind(Time_Use$GEOACL00,Time_Use$ConstructionAndRepairs)
ShoppingAndServices <- cbind(Time_Use$GEOACL00,Time_Use$ShoppingAndServices)
ChildcareExceptTeachingReadingAndTalking <- cbind(Time_Use$GEOACL00,Time_Use$ChildcareExceptTeachingReadingAndTalking)
TeachingReadingAndTalkingWithChild <- cbind(Time_Use$GEOACL00,Time_Use$TeachingReadingAndTalkingWithChild)
HouseholdManagementAndHelpFamilyMember <- cbind(Time_Use$GEOACL00,Time_Use$HouseholdManagementAndHelpFamilyMember)
OrganisationalWork <- cbind(Time_Use$GEOACL00,Time_Use$OrganisationalWork)
InformalHelpToOtherHouseholds<- cbind(Time_Use$GEOACL00,Time_Use$InformalHelpToOtherHouseholds)
ParticipatoryActivities <- cbind(Time_Use$GEOACL00,Time_Use$ParticipatoryActivities)
VisitingAndFeasts <- cbind(Time_Use$GEOACL00,Time_Use$VisitingAndFeasts)
OtherSocialLife <- cbind(Time_Use$GEOACL00,Time_Use$OtherSocialLife)
EntertainmentAndCulture <- cbind(Time_Use$GEOACL00,Time_Use$EntertainmentAndCulture)
Resting <- cbind(Time_Use$GEOACL00,Time_Use$Resting)
WalkingAndHiking <- cbind(Time_Use$GEOACL00,Time_Use$WalkingAndHiking)
SportsAndOutdoorActivitiesExceptWalkingAndHiking<- cbind(Time_Use$GEOACL00,Time_Use$SportsAndOutdoorActivitiesExceptWalkingAndHiking)
ComputerGames <- cbind(Time_Use$GEOACL00,Time_Use$ComputerGames)
Computing <- cbind(Time_Use$GEOACL00,Time_Use$Computing)
HobbiesAndGamesExceptComputingAndComputerGames <- cbind(Time_Use$GEOACL00,Time_Use$HobbiesAndGamesExceptComputingAndComputerGames)
ReadingBooks <- cbind(Time_Use$GEOACL00,Time_Use$ReadingBooks)
ReadingExceptBooks <- cbind(Time_Use$GEOACL00,Time_Use$ReadingExceptBooks)
TVAndVideo <- cbind(Time_Use$GEOACL00,Time_Use$TVAndVideo)
RadioAndMusic <- cbind(Time_Use$GEOACL00,Time_Use$RadioAndMusic)
UnspecifiedLeisure <- cbind(Time_Use$GEOACL00,Time_Use$UnspecifiedLeisure)
TravelExceptTravelRelatedToJobs<- cbind(Time_Use$GEOACL00,Time_Use$TravelExceptTravelRelatedToJobs)
TravelToFromWork <- cbind(Time_Use$GEOACL00,Time_Use$TravelToFromWork)
TravelRelatedToStudy <- cbind(Time_Use$GEOACL00,Time_Use$TravelRelatedToStudy)
TravelRelatedToShoppingAndServices <- cbind(Time_Use$GEOACL00,Time_Use$TravelRelatedToShoppingAndServices)
TransportingAChild <- cbind(Time_Use$GEOACL00,Time_Use$TransportingAChild)
TravelRelatedToOtherHouseholdPurposes<- cbind(Time_Use$GEOACL00,Time_Use$TravelRelatedToOtherHouseholdPurposes)
TravelRelatedRoLeisureSocialAndAssociativeLife <- cbind(Time_Use$GEOACL00,Time_Use$TravelRelatedRoLeisureSocialAndAssociativeLife)
UnspecifiedTravel <- cbind(Time_Use$GEOACL00,Time_Use$UnspecifiedTravel)
UnspecifiedTimeUse <- cbind(Time_Use$GEOACL00,Time_Use$UnspecifiedTimeUse)
 
PersonalCareGLC <- getLinkCommunities(PersonalCare, hcmethod = "single")
SleepGLC <- getLinkCommunities(Sleep, hcmethod = "single")
EatingGLC <- getLinkCommunities(Eating, hcmethod = "single")#K2,3
StudyGLC <- getLinkCommunities(Study, hcmethod = "single")#K2,3 
SchoolAndUniversityExceptHomeworkGLC <- getLinkCommunities(SchoolAndUniversityExceptHomework, hcmethod = "single")#K2,3
HomeworkGLC <- getLinkCommunities(Homework, hcmethod = "single")#K2,3 
FreeTimeStudyGLC <- getLinkCommunities(FreeTimeStudy, hcmethod = "single")
HouseholdAndFamilyCareGLC <- getLinkCommunities(HouseholdAndFamilyCare, hcmethod = "single")
DishWashingGLC <- getLinkCommunities(DishWashing, hcmethod = "single")#K2,3
CleaningDwellingGLC <- getLinkCommunities(CleaningDwelling, hcmethod = "single")#k2,3
HouseholdUpkeepExceptCleaningDwellingGCL <- getLinkCommunities(HouseholdUpkeepExceptCleaningDwelling, hcmethod = "single")
LaundryGCL <- getLinkCommunities(Laundry, hcmethod = "single")#K2,3
IroningGCL <- getLinkCommunities(Ironing, hcmethod = "single")3K2,3
HandicraftAndProducingTextilesAndOtherCareForTextilesGCL <- getLinkCommunities(HandicraftAndProducingTextilesAndOtherCareForTextiles, hcmethod = "single")#K2, 3 
GardeningOtherPetCareGLC <- getLinkCommunities(GardeningOtherPetCare, hcmethod = "single")#K2, 3 
CaringForPetsGCL <- getLinkCommunities(CaringForPets, hcmethod = "single")#K2,3
WalkingTheDogGLC <- getLinkCommunities(WalkingTheDog, hcmethod = "single")
ConstructionAndRepairsGCL <- getLinkCommunities(ConstructionAndRepairs, hcmethod = "single")
ShoppingAndServicesGCL <- getLinkCommunities(ShoppingAndServices, hcmethod = "single") #K2,3
ChildcareExceptTeachingReadingAndTalkingGCL <- getLinkCommunities(ChildcareExceptTeachingReadingAndTalking, hcmethod = "single")
TeachingReadingAndTalkingWithChildGLC <- getLinkCommunities(TeachingReadingAndTalkingWithChild, hcmethod = "single")#K2,3
HouseholdManagementAndHelpFamilyMemberGLC <- getLinkCommunities(HouseholdManagementAndHelpFamilyMember, hcmethod = "single") 
VisitingAndFeastsGLC <- getLinkCommunities(VisitingAndFeasts, hcmethod = "single")
EntertainmentAndCultureGLC <- getLinkCommunities(EntertainmentAndCulture, hcmethod = "single")
RestingGLC <- getLinkCommunities(Resting, hcmethod = "single")
WalkingAndHikingGLC <- getLinkCommunities(WalkingAndHiking, hcmethod = "single")
SportsAndOutdoorActivitiesExceptWalkingAndHikingGLC <- getLinkCommunities(SportsAndOutdoorActivitiesExceptWalkingAndHiking, hcmethod = "single")#K2,3
ComputingGLC <- getLinkCommunities(Computing, hcmethod = "single")
HobbiesAndGamesExceptComputingAndComputerGamesGLC <- getLinkCommunities(HobbiesAndGamesExceptComputingAndComputerGames, hcmethod = "single")#K2,3
ReadingBooksGLC <- getLinkCommunities(ReadingBooks, hcmethod = "single")
TVAndVideoGLC <- getLinkCommunities(TVAndVideo, hcmethod = "single")
RadioAndMusicGLC <- getLinkCommunities(RadioAndMusic, hcmethod = "single")#K2,3
UnspecifiedLeisureGLC <- getLinkCommunities(UnspecifiedLeisure, hcmethod = "single")#K2,3
TravelToFromWorkGCL <- getLinkCommunities(TravelToFromWork, hcmethod = "single")#K2,3
TravelRelatedToStudyGCL <- getLinkCommunities(TravelRelatedToStudy, hcmethod = "single")#K2,3
TravelRelatedToShoppingAndServicesGCL <- getLinkCommunities(TravelRelatedToShoppingAndServices, hcmethod = "single")#K2,3
TransportingAChildGCL <- getLinkCommunities(TransportingAChild, hcmethod = "single")#K2,3

#igraph_Eating<- graph.data.frame(Eating)
#igraph_Eating
#V(igraph_Eating)$type <- V(igraph_Eating)$name %in% Eating[,1]
#bipartite_mapping(igraph_Eating)
#lc <- getLinkCommunities(Eating, hcmethod = "single")
#sc <- spinglass.community(igraph_Eating)
#sc

igraph_Study<- graph.data.frame(Study)
V(igraph_Study)$type <- V(igraph_Study)$name %in% Study[,1]
bipartite_mapping(igraph_Study)
lc <- getLinkCommunities(Study, hcmethod = "single")
sc <- spinglass.community(igraph_Study)
sc

igraph_SchoolAndUniversityExceptHomework<- graph.data.frame(SchoolAndUniversityExceptHomework)
V(igraph_SchoolAndUniversityExceptHomework)$type <- V(igraph_SchoolAndUniversityExceptHomework)$name %in% Study[,1]
bipartite_mapping(igraph_SchoolAndUniversityExceptHomework)
lc <- getLinkCommunities(SchoolAndUniversityExceptHomework, hcmethod = "single")
sc <- spinglass.community(igraph_SchoolAndUniversityExceptHomework)
sc

igraph_Homework<- graph.data.frame(Homework)
V(igraph_Homework)$type <- V(igraph_Homework)$name %in% Study[,1]
bipartite_mapping(igraph_Homework)
lc <- getLinkCommunities(Homework, hcmethod = "single")
sc <- spinglass.community(igraph_Homework)
sc

igraph_DishWashing <- graph.data.frame(DishWashing)
igraph_DishWashing
V(igraph_DishWashing)$type <- V(igraph_DishWashing)$name %in% DishWashing[,1]
bipartite_mapping(igraph_DishWashing)
lc <- getLinkCommunities(DishWashing, hcmethod = "single")
sc <- spinglass.community(igraph_DishWashing)
sc

igraph_CleaningDwelling<- graph.data.frame(CleaningDwelling)
V(igraph_CleaningDwelling)$type <- V(igraph_CleaningDwelling)$name %in% CleaningDwelling[,1]
bipartite_mapping(igraph_CleaningDwelling)
lc <- getLinkCommunities(CleaningDwelling, hcmethod = "single")
sc <- spinglass.community(igraph_CleaningDwelling)
sc

igraph_Laundry<- graph.data.frame(Laundry)
V(igraph_Laundry)$type <- V(igraph_Laundry)$name %in% Laundry[,1]
bipartite_mapping(igraph_Laundry)
lc <- getLinkCommunities(Laundry, hcmethod = "single")
sc <- spinglass.community(igraph_Laundry)
sc

igraph_Ironing<- graph.data.frame(Ironing)
V(igraph_Ironing)$type <- V(igraph_Ironing)$name %in% Ironing[,1]
bipartite_mapping(igraph_Ironing)
lc <- getLinkCommunities(Ironing, hcmethod = "single")
sc <- spinglass.community(igraph_Ironing)
sc

igraph_HandicraftAndProducingTextilesAndOtherCareForTextiles<- graph.data.frame(HandicraftAndProducingTextilesAndOtherCareForTextiles)
igraph_HandicraftAndProducingTextilesAndOtherCareForTextiles
V(igraph_HandicraftAndProducingTextilesAndOtherCareForTextiles)$type <- V(igraph_HandicraftAndProducingTextilesAndOtherCareForTextiles)$name %in% HandicraftAndProducingTextilesAndOtherCareForTextiles[,1]
bipartite_mapping(igraph_HandicraftAndProducingTextilesAndOtherCareForTextiles)
lc <- getLinkCommunities(HandicraftAndProducingTextilesAndOtherCareForTextiles, hcmethod = "single")
sc <- spinglass.community(igraph_HandicraftAndProducingTextilesAndOtherCareForTextiles)
sc

igraph_GardeningOtherPetCare <- graph.data.frame(GardeningOtherPetCare)
igraph_HandicraftAndProducingTextilesAndOtherCareForTextiles
V(igraph_GardeningOtherPetCare)$type <- V(igraph_GardeningOtherPetCare)$name %in% GardeningOtherPetCare[,1]
bipartite_mapping(igraph_GardeningOtherPetCare )
lc <- getLinkCommunities(GardeningOtherPetCare , hcmethod = "single")
sc <- spinglass.community(igraph_GardeningOtherPetCare )
sc

igraph_CaringForPets<- graph.data.frame(CaringForPets)
igraph_CaringForPets
V(igraph_CaringForPets)$type <- V(igraph_CaringForPets)$name %in% CaringForPets[,1]
bipartite_mapping(igraph_CaringForPets)
lc <- getLinkCommunities(CaringForPets, hcmethod = "single")
sc <- spinglass.community(igraph_CaringForPets)
sc

igraph_ShoppingAndServices <- graph.data.frame(ShoppingAndServices)
igraph_ShoppingAndServices 
V(igraph_ShoppingAndServices )$type <- V(igraph_Eating)$name %in% ShoppingAndServices [,1]
bipartite_mapping(igraph_ShoppingAndServices )
lc <- getLinkCommunities(ShoppingAndServices , hcmethod = "single")
sc <- spinglass.community(igraph_ShoppingAndServices )
sc

igraph_TeachingReadingAndTalkingWithChild <- graph.data.frame(TeachingReadingAndTalkingWithChild )
igraph_TeachingReadingAndTalkingWithChild 
V(igraph_TeachingReadingAndTalkingWithChild)$type <- V(igraph_Eating)$name %in% TeachingReadingAndTalkingWithChild[,1]
bipartite_mapping(igraph_TeachingReadingAndTalkingWithChild )
lc <- getLinkCommunities(TeachingReadingAndTalkingWithChild , hcmethod = "single")
sc <- spinglass.community(igraph_TeachingReadingAndTalkingWithChild )
sc

igraph_SportsAndOutdoorActivitiesExceptWalkingAndHiking <- graph.data.frame(SportsAndOutdoorActivitiesExceptWalkingAndHiking)
igraph_SportsAndOutdoorActivitiesExceptWalkingAndHiking
V(igraph_SportsAndOutdoorActivitiesExceptWalkingAndHiking)$type <- V(igraph_Eating)$name %in% SportsAndOutdoorActivitiesExceptWalkingAndHiking[,1]
bipartite_mapping(igraph_SportsAndOutdoorActivitiesExceptWalkingAndHiking)
lc <- getLinkCommunities(SportsAndOutdoorActivitiesExceptWalkingAndHiking, hcmethod = "single")
sc <- spinglass.community(igraph_SportsAndOutdoorActivitiesExceptWalkingAndHiking)
sc

igraph_HobbiesAndGamesExceptComputingAndComputerGames <- graph.data.frame(HobbiesAndGamesExceptComputingAndComputerGames)
igraph_HobbiesAndGamesExceptComputingAndComputerGames
V(igraph_HobbiesAndGamesExceptComputingAndComputerGames)$type <- V(igraph_Eating)$name %in% HobbiesAndGamesExceptComputingAndComputerGames[,1]
bipartite_mapping(igraph_HobbiesAndGamesExceptComputingAndComputerGames)
lc <- getLinkCommunities(HobbiesAndGamesExceptComputingAndComputerGames, hcmethod = "single")
sc <- spinglass.community(igraph_HobbiesAndGamesExceptComputingAndComputerGames)
sc

igraph_RadioAndMusic <- graph.data.frame(RadioAndMusic)
igraph_RadioAndMusic
V(igraph_RadioAndMusic)$type <- V(igraph_TravelRelatedToStudy)$name %in% TravelRelatedToStudy[,1]
bipartite_mapping(igraph_RadioAndMusic)
lc <- getLinkCommunities(RadioAndMusic, hcmethod = "single")
sc <- spinglass.community(igraph_RadioAndMusic)
sc

igraph_UnspecifiedLeisure <- graph.data.frame(UnspecifiedLeisure)
igraph_UnspecifiedLeisure
V(igraph_UnspecifiedLeisure)$type <- V(igraph_UnspecifiedLeisure)$name %in% UnspecifiedLeisure[,1]
bipartite_mapping(igraph_DishWashing)
lc <- getLinkCommunities(UnspecifiedLeisure, hcmethod = "single")
sc <- spinglass.community(igraph_UnspecifiedLeisure)
sc

igraph_TravelToFromWork <- graph.data.frame(TravelToFromWork)
igraph_TravelToFromWork
V(igraph_TravelToFromWork)$type <- V(igraph_Eating)$name %in% TravelToFromWork[,1]
bipartite_mapping(igraph_TravelToFromWork)
lc <- getLinkCommunities(TravelToFromWork, hcmethod = "single")
sc <- spinglass.community(igraph_TravelToFromWork)
sc

igraph_TravelRelatedToStudy <- graph.data.frame(TravelRelatedToStudy)
igraph_TravelRelatedToStudy
V(igraph_TravelRelatedToStudy)$type <- V(igraph_TravelRelatedToStudy)$name %in% TravelRelatedToStudy[,1]
bipartite_mapping(igraph_TravelRelatedToStudy)
lc <- getLinkCommunities(TravelRelatedToStudy, hcmethod = "single")
sc <- spinglass.community(igraph_TravelRelatedToStudy)
sc

{
    print(
igraph_TravelRelatedToShoppingAndServices<- graph.data.frame(TravelRelatedToShoppingAndServices)
igraph_TravelRelatedToShoppingAndServices
V(igraph_TravelRelatedToShoppingAndServices)$type <- V(igraph_TravelRelatedToShoppingAndServices)$name %in% TravelRelatedToShoppingAndServices[,1]
bipartite_mapping(igraph_TravelRelatedToShoppingAndServices)
lc <- getLinkCommunities(TravelRelatedToShoppingAndServices, hcmethod = "single")
sc <- spinglass.community(igraph_TravelRelatedToShoppingAndServices)
sc

igraph_TransportingAChild<- graph.data.frame(TransportingAChild)
igraph_TransportingAChild
V(igraph_TransportingAChild)$type <- V(igraph_TransportingAChild)$name %in% TravelRelatedToShoppingAndServices[,1]
bipartite_mapping(igraph_TransportingAChild)
lc <- getLinkCommunities(TransportingAChild, hcmethod = "single")
sc <- spinglass.community(igraph_TransportingAChild)
sc

#  ================ Tree Layouts before Compress ================

#1 Fruchterman.reingold.layout(Tree layout) 
#tkid <- tkplot(igraph_Eating)
#V(igraph_Eating)$frame.color <- "white"
#V(igraph_Eating)$color = "orange"
#V(igraph_Eating)$size = 9
#E(igraph_Eating)$arrow.mode = 0
#plot(igraph_Eating, vertex.label.cex=.4, layout=layout.fruchterman.reingold, main="Tree layout (Eight K2, 3 Bipartite)")

#1 Fruchterman.reingold.layout(Tree layout) 
tkid <- tkplot(igraph_Study)
V(igraph_Study)$frame.color <- "white"
V(igraph_Study)$color = "orange"
V(igraph_Study)$size = 9
E(igraph_Study)$arrow.mode = 0
plot(igraph_Study, vertex.label.cex=.4, layout=layout.fruchterman.reingold, main="Tree layout (Eight K2, 3 Bipartite)")

#2 Fruchterman.reingold.layout(Tree layout) 
tkid <- tkplot(igraph_SchoolAndUniversityExceptHomework)
V(igraph_SchoolAndUniversityExceptHomework)$frame.color <- "white"
V(igraph_SchoolAndUniversityExceptHomework)$color = "orange"
V(igraph_SchoolAndUniversityExceptHomework)$size = 9
E(igraph_SchoolAndUniversityExceptHomework)$arrow.mode = 0
plot(igraph_SchoolAndUniversityExceptHomework, vertex.label.cex=.4, layout=layout.fruchterman.reingold, main="Tree layout (Eight K2, 3 Bipartite)")

#3 Fruchterman.reingold.layout(Tree layout) 
tkid <- tkplot(igraph_Homework)
V(igraph_Homework)$frame.color <- "white"
V(igraph_Homework)$color = "orange"
V(igraph_Homework)$size = 9
E(igraph_Homework)$arrow.mode = 0
plot(igraph_Homework, vertex.label.cex=.4, layout=layout.fruchterman.reingold, main="Tree layout (Eight K2, 3 Bipartite)")

#4 Fruchterman.reingold.layout(Tree layout) 
tkid <- tkplot(igraph_DishWashing)
V(igraph_DishWashing)$frame.color <- "white"
V(igraph_DishWashing)$color = "orange"
V(igraph_DishWashing)$size = 9
E(igraph_DishWashing)$arrow.mode = 0
plot(igraph_DishWashing, vertex.label.cex=.4, layout=layout.fruchterman.reingold, main="Tree layout (Eight K2, 3 Bipartite)")

#5 Fruchterman.reingold.layout(Tree layout) 
tkid <- tkplot(igraph_CleaningDwelling)
V(igraph_CleaningDwelling)$frame.color <- "white"
V(igraph_CleaningDwelling)$color = "orange"
V(igraph_CleaningDwelling)$size = 9
E(igraph_CleaningDwelling)$arrow.mode = 0
plot(igraph_CleaningDwelling, vertex.label.cex=.4, layout=layout.fruchterman.reingold, main="Tree layout (Eight K2, 3 Bipartite)")

#6 Fruchterman.reingold.layout(Tree layout) 
tkid <- tkplot(igraph_Laundry)
V(igraph_Laundry)$frame.color <- "white"
V(igraph_Laundry)$color = "orange"
V(igraph_Laundry)$size = 9
E(igraph_Laundry)$arrow.mode = 0
plot(igraph_Laundry, vertex.label.cex=.4, layout=layout.fruchterman.reingold, main="Tree layout (Eight K2, 3 Bipartite)")

#7 Fruchterman.reingold.layout(Tree layout) 
tkid <- tkplot(igraph_Ironing)
V(igraph_Ironing)$frame.color <- "white"
V(igraph_Ironing)$color = "orange"
V(igraph_Ironing)$size = 9
E(igraph_Ironing)$arrow.mode = 0
plot(igraph_Ironing, vertex.label.cex=.4, layout=layout.fruchterman.reingold, main="Tree layout (Eight K2, 3 Bipartite)")

#8 Fruchterman.reingold.layout(Tree layout) 
tkid <- tkplot(igraph_HandicraftAndProducingTextilesAndOtherCareForTextiles)
V(igraph_HandicraftAndProducingTextilesAndOtherCareForTextiles)$frame.color <- "white"
V(igraph_HandicraftAndProducingTextilesAndOtherCareForTextiles)$color = "orange"
V(igraph_HandicraftAndProducingTextilesAndOtherCareForTextiles)$size = 9
E(igraph_HandicraftAndProducingTextilesAndOtherCareForTextiles)$arrow.mode = 0
plot(igraph_HandicraftAndProducingTextilesAndOtherCareForTextiles, vertex.label.cex=.4, layout=layout.fruchterman.reingold, main="Tree layout (Eight K2, 3 Bipartite)")

#9 Fruchterman.reingold.layout(Tree layout) 
tkid <- tkplot(igraph_GardeningOtherPetCare )
V(igraph_GardeningOtherPetCare )$frame.color <- "white"
V(igraph_GardeningOtherPetCare )$color = "orange"
V(igraph_GardeningOtherPetCare )$size = 9
E(igraph_GardeningOtherPetCare )$arrow.mode = 0
plot(igraph_GardeningOtherPetCare , vertex.label.cex=.4, layout=layout.fruchterman.reingold, main="Tree layout (Eight K2, 3 Bipartite)")

#10 Fruchterman.reingold.layout(Tree layout) 
tkid <- tkplot(igraph_CaringForPets)
V(igraph_CaringForPets)$frame.color <- "white"
V(igraph_CaringForPets)$color = "orange"
V(igraph_CaringForPets)$size = 9
E(igraph_CaringForPets)$arrow.mode = 0
plot(igraph_CaringForPets, vertex.label.cex=.4, layout=layout.fruchterman.reingold, main="Tree layout (Eight K2, 3 Bipartite)")

#11 Fruchterman.reingold.layout(Tree layout) 
tkid <- tkplot(igraph_ShoppingAndServices)
V(igraph_ShoppingAndServices)$frame.color <- "white"
V(igraph_ShoppingAndServices)$color = "orange"
V(igraph_ShoppingAndServices)$size = 9
E(igraph_ShoppingAndServices)$arrow.mode = 0
plot(igraph_ShoppingAndServices, vertex.label.cex=.4, layout=layout.fruchterman.reingold, main="Tree layout (Eight K2, 3 Bipartite)")

#12 Fruchterman.reingold.layout(Tree layout) 
tkid <- tkplot(igraph_TeachingReadingAndTalkingWithChild)
V(igraph_TeachingReadingAndTalkingWithChild)$frame.color <- "white"
V(igraph_TeachingReadingAndTalkingWithChild)$color = "orange"
V(igraph_TeachingReadingAndTalkingWithChild)$size = 9
E(igraph_TeachingReadingAndTalkingWithChild)$arrow.mode = 0
plot(igraph_TeachingReadingAndTalkingWithChild, vertex.label.cex=.4, layout=layout.fruchterman.reingold, main="Tree layout (Eight K2, 3 Bipartite)")

#13 Fruchterman.reingold.layout(Tree layout) 
tkid <- tkplot(igraph_SportsAndOutdoorActivitiesExceptWalkingAndHiking)
V(igraph_SportsAndOutdoorActivitiesExceptWalkingAndHiking)$frame.color <- "white"
V(igraph_SportsAndOutdoorActivitiesExceptWalkingAndHiking)$color = "orange"
V(igraph_SportsAndOutdoorActivitiesExceptWalkingAndHiking)$size = 9
E(igraph_SportsAndOutdoorActivitiesExceptWalkingAndHiking)$arrow.mode = 0
plot(igraph_SportsAndOutdoorActivitiesExceptWalkingAndHiking, vertex.label.cex=.4, layout=layout.fruchterman.reingold, main="Tree layout (Eight K2, 3 Bipartite)")

#14 Fruchterman.reingold.layout(Tree layout) 
tkid <- tkplot(igraph_HobbiesAndGamesExceptComputingAndComputerGames)
V(igraph_HobbiesAndGamesExceptComputingAndComputerGames)$frame.color <- "white"
V(igraph_HobbiesAndGamesExceptComputingAndComputerGames)$color = "orange"
V(igraph_HobbiesAndGamesExceptComputingAndComputerGames)$size = 9
E(igraph_HobbiesAndGamesExceptComputingAndComputerGames)$arrow.mode = 0
plot(igraph_HobbiesAndGamesExceptComputingAndComputerGames, vertex.label.cex=.4, layout=layout.fruchterman.reingold, main="Tree layout (Eight K2, 3 Bipartite)")

#15 Fruchterman.reingold.layout(Tree layout) 
tkid <- tkplot(igraph_RadioAndMusic)
V(igraph_RadioAndMusic)$frame.color <- "white"
V(igraph_RadioAndMusic)$color = "orange"
V(igraph_TravelToFromWork)$size = 9
E(igraph_RadioAndMusic)$arrow.mode = 0
plot(igraph_RadioAndMusic, vertex.label.cex=.4, layout=layout.fruchterman.reingold, main="Tree layout (Eight K2, 3 Bipartite)")

#16 Fruchterman.reingold.layout(Tree layout) 
tkid <- tkplot(igraph_UnspecifiedLeisure)
V(igraph_UnspecifiedLeisure)$frame.color <- "white"
V(igraph_UnspecifiedLeisure)$color = "orange"
V(igraph_UnspecifiedLeisure)$size = 9
E(igraph_UnspecifiedLeisure)$arrow.mode = 0
plot(igraph_UnspecifiedLeisure, vertex.label.cex=.4, layout=layout.fruchterman.reingold, main="Tree layout (Eight K2, 3 Bipartite)")

#17 Fruchterman.reingold.layout(Tree layout) 
tkid <- tkplot(igraph_TravelToFromWork)
V(igraph_TravelToFromWork)$frame.color <- "white"
V(igraph_TravelToFromWork)$color = "orange"
V(igraph_TravelToFromWork)$size = 9
E(igraph_TravelToFromWork)$arrow.mode = 0
plot(igraph_TravelToFromWork, vertex.label.cex=.4, layout=layout.fruchterman.reingold, main="Tree layout (Eight K2, 3 Bipartite)")

#18 Fruchterman.reingold.layout(Tree layout) 
tkid <- tkplot(igraph_TravelRelatedToStudy)
V(igraph_TravelRelatedToStudy)$frame.color <- "white"
V(igraph_TravelRelatedToStudy)$color = "orange"
V(igraph_TravelRelatedToStudy)$size = 9
E(igraph_TravelRelatedToStudy)$arrow.mode = 0
plot(igraph_TravelRelatedToStudy, vertex.label.cex=.4, layout=layout.fruchterman.reingold, main="Tree layout (Eight K2, 3 Bipartite)")

#19 Fruchterman.reingold.layout(Tree layout) 
tkid <- tkplot(igraph_TravelRelatedToShoppingAndServices)
V(igraph_TravelRelatedToShoppingAndServices)$frame.color <- "white"
V(igraph_TravelRelatedToShoppingAndServices)$color = "orange"
V(igraph_TravelRelatedToShoppingAndServices)$size = 9
E(igraph_TravelRelatedToShoppingAndServices)$arrow.mode = 0
plot(igraph_TravelRelatedToShoppingAndServices, vertex.label.cex=.4, layout=layout.fruchterman.reingold, main="Tree layout (Eight K2, 3 Bipartite)")

#20 Fruchterman.reingold.layout(Tree layout) 
tkid <- tkplot(igraph_TransportingAChild)
V(igraph_TransportingAChild)$frame.color <- "white"
V(igraph_TransportingAChild)$color = "orange"
V(igraph_TransportingAChild)$size = 9
E(igraph_TransportingAChild)$arrow.mode = 0
plot(igraph_TransportingAChild, vertex.label.cex=.4, layout=layout.fruchterman.reingold, main="Tree layout (Eight K2, 3 Bipartite)")

igraph1 <- graph.data.frame(Time_Use)
igraph1
V(igraph1)$type <- V(igraph)$name %in% Time_Use[,1]
bipartite.projection(igraph1)
bipartite_mapping(igraph1)
lc <- largest.cliques(igraph1)
lc

# Fruchterman.reingold.layout(Tree layout) 
V(igraph1)$frame.color <- "white"
V(igraph1)$color = "orange"
V(igraph1)$size = 9
E(igraph1)$arrow.mode = 0
plot(igraph1, vertex.label.cex=.1, layout=layout.fruchterman.reingold, main="Tree layout (30 K2, 3 Bipartite)")

#end.time <- Sys.time()
#time.taken <- end.time - start.time
#time.taken

#  ================ Compress Every K2,3 Bipartite ================

else(
#Runtime
start.time <- Sys.time()

#Compress1 <- data.frame(Time_Use)
#Compress1 
#attach(Compress1)
#GEOACL00
#Compress1$GEOACL00[8:8]= c("B1") # K2,3 Bipartite 1
#Compress1$GEOACL00[11:11]= c("B1") 
#Compress1$GEOACL00[59:59]= c("B1") 
#Compress1$GEOACL00[67:67]= c("B1") 
#Compress1$GEOACL00[70:70]= c("B1")
#Compress1$GEOACL00[117:117]= c("B1")
#attach(Compress1)
#GEOACL00
#attach(Compress1)
#Eating
#Compress1$Eating[8:8]= c("B1") # K2,3 Bipartite 1
#Compress1$Eating[11:11]= c("B1") 
#Compress1$Eating[59:59]= c("B1") 
#Compress1$Eating[67:67]= c("B1") 
#Compress1$Eating[70:70]= c("B1")
#Compress1$Eating[117:117]= c("B1")  
#attach(Compress1)
#Eating

Compress <- data.frame(Time_Use)
Compress 
attach(Compress)
GEOACL00
Compress$GEOACL00[11:11]= c("B1") # K2,3 Bipartite 1
Compress$GEOACL00[37:37]= c("B1") 
Compress$GEOACL00[40:40]= c("B1") 
Compress$GEOACL00[69:69]= c("B1") 
Compress$GEOACL00[70:70]= c("B1")
Compress$GEOACL00[99:99]= c("B1") 
attach(Compress)
GEOACL00
attach(Compress)
Study
Compress$Study[11:11]= c("B1") # K2,3 Bipartite 1
Compress$Study[37:37]= c("B1") 
Compress$Study[40:40]= c("B1") 
Compress$Study[69:69]= c("B1") 
Compress$Study[70:70]= c("B1")
Compress$Study[99:99]= c("B1")
attach(Compress)
Study

attach(Compress)
GEOACL00
Compress$GEOACL00[7:7]= c("B2") # K2,3 Bipartite 2
Compress$GEOACL00[50:50]= c("B2") 
Compress$GEOACL00[58:58]= c("B2") 
Compress$GEOACL00[67:67]= c("B2") 
Compress$GEOACL00[109:109]= c("B2")
Compress$GEOACL00[117:117]= c("B2") 
attach(Compress)
GEOACL00
attach(Compress)
Study
Compress$Study[7:7]= c("B2") # K2,3 Bipartite 2
Compress$Study[50:50]= c("B2") 
Compress$Study[58:58]= c("B2") 
Compress$Study[67:67]= c("B2") 
Compress$Study[109:109]= c("B2")
Compress$Study[117:117]= c("B2")
attach(Compress)
Study

attach(Compress)
GEOACL00
Compress$GEOACL00[6:6]= c("B3") # K2,3 Bipartite 3
Compress$GEOACL00[14:14]= c("B3") 
Compress$GEOACL00[57:57]= c("B3")
Compress$GEOACL00[65:65]= c("B3") 
Compress$GEOACL00[73:73]= c("B3")
Compress$GEOACL00[115:115]= c("B3")  
attach(Compress)
GEOACL00
attach(Compress)
SchoolAndUniversityExceptHomework
Compress$SchoolAndUniversityExceptHomework[6:6]= c("B3") # K2,3 Bipartite 3
Compress$SchoolAndUniversityExceptHomework[14:14]= c("B3") 
Compress$SchoolAndUniversityExceptHomework[57:57]= c("B3") 
Compress$SchoolAndUniversityExceptHomework[65:65]= c("B3") 
Compress$SchoolAndUniversityExceptHomework[73:73]= c("B3")
Compress$SchoolAndUniversityExceptHomework[115:115]= c("B3")  
attach(Compress)
SchoolAndUniversityExceptHomework

attach(Compress)
GEOACL00
Compress$GEOACL00[10:10]= c("B4") # K2,3 Bipartite 4
Compress$GEOACL00[30:30]= c("B4") 
Compress$GEOACL00[32:32]= c("B4")
Compress$GEOACL00[69:69]= c("B4") 
Compress$GEOACL00[89:89]= c("B4")
Compress$GEOACL00[91:91]= c("B4")  
attach(Compress)
GEOACL00
attach(Compress)
SchoolAndUniversityExceptHomework
Compress$SchoolAndUniversityExceptHomework[10:10]= c("B4") # K2,3 Bipartite 4
Compress$SchoolAndUniversityExceptHomework[30:30]= c("B4") 
Compress$SchoolAndUniversityExceptHomework[32:32]= c("B4") 
Compress$SchoolAndUniversityExceptHomework[69:69]= c("B4") 
Compress$SchoolAndUniversityExceptHomework[89:89]= c("B4")
Compress$SchoolAndUniversityExceptHomework[91:91]= c("B4")  
attach(Compress)
SchoolAndUniversityExceptHomework
 
attach(Compress)
GEOACL00
Compress$GEOACL00[1:1]= c("B5") # K2,3 Bipartite 5
Compress$GEOACL00[11:11]= c("B5") 
Compress$GEOACL00[48:48]= c("B5")
Compress$GEOACL00[60:60]= c("B5") 
Compress$GEOACL00[70:70]= c("B5")
Compress$GEOACL00[107:107]= c("B5")  
attach(Compress)
GEOACL00
attach(Compress)
SchoolAndUniversityExceptHomework
Compress$SchoolAndUniversityExceptHomework[1:1]= c("B5") # K2,3 Bipartite 5
Compress$SchoolAndUniversityExceptHomework[11:11]= c("B5") 
Compress$SchoolAndUniversityExceptHomework[48:48]= c("B5") 
Compress$SchoolAndUniversityExceptHomework[60:60]= c("B5") 
Compress$SchoolAndUniversityExceptHomework[70:70]= c("B5")
Compress$SchoolAndUniversityExceptHomework[107:107]= c("B5")  
attach(Compress)
SchoolAndUniversityExceptHomework

attach(Compress)
GEOACL00
Compress$GEOACL00[3:3]= c("B6") # K2,3 Bipartite 6
Compress$GEOACL00[39:39]= c("B6") 
Compress$GEOACL00[54:54]= c("B6")
Compress$GEOACL00[62:62]= c("B6") 
Compress$GEOACL00[98:98]= c("B6")
Compress$GEOACL00[112:112]= c("B6")  
attach(Compress)
GEOACL00
attach(Compress)
SchoolAndUniversityExceptHomework
Compress$SchoolAndUniversityExceptHomework[3:3]= c("B6") # K2,3 Bipartite 6
Compress$SchoolAndUniversityExceptHomework[39:39]= c("B6") 
Compress$SchoolAndUniversityExceptHomework[54:54]= c("B6") 
Compress$SchoolAndUniversityExceptHomework[62:62]= c("B6") 
Compress$SchoolAndUniversityExceptHomework[98:98]= c("B6")
Compress$SchoolAndUniversityExceptHomework[112:112]= c("B6")  
attach(Compress)
SchoolAndUniversityExceptHomework

attach(Compress)
GEOACL00
Compress$GEOACL00[4:4]= c("B7") # K2,3 Bipartite 7
Compress$GEOACL00[16:16]= c("B7") 
Compress$GEOACL00[55:55]= c("B7")
Compress$GEOACL00[63:63]= c("B7") 
Compress$GEOACL00[75:75]= c("B7")
Compress$GEOACL00[113:113]= c("B7")  
attach(Compress)
GEOACL00
attach(Compress)
SchoolAndUniversityExceptHomework
Compress$SchoolAndUniversityExceptHomework[4:4]= c("B7") # K2,3 Bipartite 7
Compress$SchoolAndUniversityExceptHomework[16:16]= c("B7") 
Compress$SchoolAndUniversityExceptHomework[55:55]= c("B7") 
Compress$SchoolAndUniversityExceptHomework[63:63]= c("B7") 
Compress$SchoolAndUniversityExceptHomework[75:75]= c("B7")
Compress$SchoolAndUniversityExceptHomework[113:113]= c("B7")  
attach(Compress)
SchoolAndUniversityExceptHomework
 
attach(Compress)
GEOACL00
Compress$GEOACL00[12:12]= c("B8") # K2,3 Bipartite 8
Compress$GEOACL00[38:38]= c("B8") 
Compress$GEOACL00[41:41]= c("B8") 
Compress$GEOACL00[71:71]= c("B8") 
Compress$GEOACL00[97:97]= c("B8")
Compress$GEOACL00[100:100]= c("B8")
attach(Compress)
GEOACL00
attach(Compress)
Homework
Compress$Homework[12:12]= c("B8") # K2,3 Bipartite 8
Compress$Homework[38:38]= c("B8") 
Compress$Homework[41:41]= c("B8") 
Compress$Homework[71:71]= c("B8") 
Compress$Homework[97:97]= c("B8")
Compress$Homework[100:100]= c("B8")  
attach(Compress)
Homework

attach(Compress)
GEOACL00
Compress$GEOACL00[8:8]= c("B9") # K2,3 Bipartite 9
Compress$GEOACL00[9:9]= c("B9") 
Compress$GEOACL00[59:59]= c("B9") 
Compress$GEOACL00[67:67]= c("B9") 
Compress$GEOACL00[68:68]= c("B9")
Compress$GEOACL00[117:117]= c("B9")
attach(Compress)
GEOACL00
attach(Compress)
DishWashing
Compress$DishWashing[8:8]= c("B9") # K2,3 Bipartite 9
Compress$DishWashing[9:9]= c("B9") 
Compress$DishWashing[59:59]= c("B9")
Compress$DishWashing[67:67]= c("B9") 
Compress$DishWashing[68:68]= c("B9")
Compress$DishWashing[117:117]= c("B9")  
attach(Compress)
DishWashing
 
attach(Compress)
GEOACL00
Compress$GEOACL00[4:4]= c("B10") # K2,3 Bipartite 10
Compress$GEOACL00[10:10]= c("B10") 
Compress$GEOACL00[55:55]= c("B10") 
Compress$GEOACL00[63:63]= c("B10") 
Compress$GEOACL00[69:69]= c("B10") 
Compress$GEOACL00[113:113]= c("B10") 
attach(Compress)
GEOACL00
attach(Compress)
CleaningDwelling
Compress$CleaningDwelling[4:4]= c("B10") # K2,3 Bipartite 10
Compress$CleaningDwelling[10:10]= c("B10") 
Compress$CleaningDwelling[55:55]= c("B10") 
Compress$CleaningDwelling[63:63]= c("B10") 
Compress$CleaningDwelling[69:69]= c("B10") 
Compress$CleaningDwelling[113:113]= c("B10") 
attach(Compress)
CleaningDwelling
 
attach(Compress)
GEOACL00
Compress$GEOACL00[3:3]= c("B11") # K2,3 Bipartite 11
Compress$GEOACL00[12:12]= c("B11") 
Compress$GEOACL00[54:54]= c("B11")
Compress$GEOACL00[62:62]= c("B11") 
Compress$GEOACL00[71:71]= c("B11")
Compress$GEOACL00[112:112]= c("B11")    
attach(Compress)
GEOACL00
attach(Compress)
Laundry
Compress$Laundry[3:3]= c("B11") # K2,3 Bipartite 11
Compress$Laundry[12:12]= c("B11") 
Compress$Laundry[54:54]= c("B11") 
Compress$Laundry[62:62]= c("B11") 
Compress$Laundry[71:71]= c("B11") 
Compress$Laundry[112:112]= c("B11") 
attach(Compress)
Laundry

attach(Compress)
GEOACL00
Compress$GEOACL00[4:4]= c("B12") # K2,3 Bipartite 12
Compress$GEOACL00[10:10]= c("B12") 
Compress$GEOACL00[55:55]= c("B12")
Compress$GEOACL00[63:63]= c("B12") 
Compress$GEOACL00[69:69]= c("B12")
Compress$GEOACL00[113:113]= c("B12")    
attach(Compress)
GEOACL00
attach(Compress)
Laundry
Compress$Laundry[4:4]= c("B12") # K2,3 Bipartite 12
Compress$Laundry[10:10]= c("B12") 
Compress$Laundry[55:55]= c("B12") 
Compress$Laundry[63:63]= c("B12") 
Compress$Laundry[69:69]= c("B12") 
Compress$Laundry[113:113]= c("B12") 
attach(Compress)
Laundry

attach(Compress)
GEOACL00
Compress$GEOACL00[4:4]= c("B13") # K2,3 Bipartite 13
Compress$GEOACL00[50:50]= c("B13") 
Compress$GEOACL00[55:55]= c("B13")
Compress$GEOACL00[63:63]= c("B13") 
Compress$GEOACL00[109:109]= c("B13") 
Compress$GEOACL00[113:113]= c("B13") 
attach(Compress)
GEOACL00
attach(Compress)
Ironing
Compress$Ironing[4:4]= c("B13") # K2,3 Bipartite 13
Compress$Ironing[50:50]= c("B13") 
Compress$Ironing[55:55]= c("B13")
Compress$Ironing[63:63]= c("B13") 
Compress$Ironing[109:109]= c("B13")
Compress$Ironing[113:113]= c("B13")    
attach(Compress)
Ironing

attach(Compress)
GEOACL00
Compress$GEOACL00[10:10]= c("B14") # K2,3 Bipartite 14
Compress$GEOACL00[15:15]= c("B14") 
Compress$GEOACL00[24:24]= c("B14")
Compress$GEOACL00[70:70]= c("B14") 
Compress$GEOACL00[74:74]= c("B14") 
Compress$GEOACL00[83:83]= c("B14") 
attach(Compress)
GEOACL00
attach(Compress)
Ironing
Compress$Ironing[4:4]= c("B14") # K2,3 Bipartite 14
Compress$Ironing[50:50]= c("B14") 
Compress$Ironing[55:55]= c("B14")
Compress$Ironing[63:63]= c("B14") 
Compress$Ironing[109:109]= c("B14")
Compress$Ironing[113:113]= c("B14")    
attach(Compress)
Ironing

attach(Compress)
GEOACL00
Compress$GEOACL00[10:10]= c("B15") # K2,3 Bipartite 15
Compress$GEOACL00[13:13]= c("B15") 
Compress$GEOACL00[42:42]= c("B15") 
Compress$GEOACL00[69:69]= c("B15") 
Compress$GEOACL00[72:72]= c("B15")
Compress$GEOACL00[101:101]= c("B15")
attach(Compress)
GEOACL00
attach(Compress)
HandicraftAndProducingTextilesAndOtherCareForTextiles
Compress$HandicraftAndProducingTextilesAndOtherCareForTextiles[10:10]= c("B15") # K2,3 Bipartite 15
Compress$HandicraftAndProducingTextilesAndOtherCareForTextiles[13:13]= c("B15") 
Compress$HandicraftAndProducingTextilesAndOtherCareForTextiles[42:42]= c("B15") 
Compress$HandicraftAndProducingTextilesAndOtherCareForTextiles[69:69]= c("B15") 
Compress$HandicraftAndProducingTextilesAndOtherCareForTextiles[72:72]= c("B15") 
Compress$HandicraftAndProducingTextilesAndOtherCareForTextiles[101:101]= c("B15") 
attach(Compress)
HandicraftAndProducingTextilesAndOtherCareForTextiles

attach(Compress)
GEOACL00
Compress$GEOACL00[44:44]= c("B16") # K2,3 Bipartite 16
Compress$GEOACL00[47:47]= c("B16") 
Compress$GEOACL00[49:49]= c("B16") 
Compress$GEOACL00[103:103]= c("B16") 
Compress$GEOACL00[106:106]= c("B16")
Compress$GEOACL00[109:109]= c("B16")
attach(Compress)
GEOACL00
attach(Compress)
HandicraftAndProducingTextilesAndOtherCareForTextiles
Compress$HandicraftAndProducingTextilesAndOtherCareForTextiles[44:44]= c("B16") # K2,3 Bipartite 16
Compress$HandicraftAndProducingTextilesAndOtherCareForTextiles[47:47]= c("B16") 
Compress$HandicraftAndProducingTextilesAndOtherCareForTextiles[49:49]= c("B16") 
Compress$HandicraftAndProducingTextilesAndOtherCareForTextiles[103:103]= c("B16") 
Compress$HandicraftAndProducingTextilesAndOtherCareForTextiles[106:106]= c("B16") 
Compress$HandicraftAndProducingTextilesAndOtherCareForTextiles[109:109]= c("B16") 
attach(Compress)
HandicraftAndProducingTextilesAndOtherCareForTextiles

Compress18 <- data.frame(Time_Use)
Compress18 
attach(Compress18)
GEOACL00
Compress$GEOACL00[4:4]= c("B17") # K2,3 Bipartite 17
Compress$GEOACL00[44:44]= c("B17") 
Compress$GEOACL00[55:55]= c("B17") 
Compress$GEOACL00[63:63]= c("B17") 
Compress$GEOACL00[103:103]= c("B17") 
Compress$GEOACL00[113:113]= c("B17") 
attach(Compress)
GEOACL00
attach(Compress)
GardeningOtherPetCare 
Compress$GardeningOtherPetCare [4:4]= c("B17") # K2,3 Bipartite 17
Compress$GardeningOtherPetCare [44:44]= c("B17") 
Compress$GardeningOtherPetCare [55:55]= c("B17") 
Compress$GardeningOtherPetCare [63:63]= c("B17")
Compress$GardeningOtherPetCare [03:103]= c("B17") 
Compress$GardeningOtherPetCare [113:113]= c("B17") 
attach(Compress)
GardeningOtherPetCare 

attach(Compress)
GEOACL00
Compress$GEOACL00[1:1]= c("B18") # K2,3 Bipartite 18
Compress$GEOACL00[44:44]= c("B18") 
Compress$GEOACL00[60:60]= c("B18")
Compress$GEOACL00[64:64]= c("B18") 
Compress$GEOACL00[102:102]= c("B18") 
Compress$GEOACL00[103:103]= c("B18")  
attach(Compress)
GEOACL00
attach(Compress)
CaringForPets
Compress$CaringForPets[1:1]= c("B18") # K2,3 Bipartite 18
Compress$CaringForPets[44:44]= c("B18") 
Compress$CaringForPets[60:60]= c("B18") 
Compress$CaringForPets[64:64]= c("B18") 
Compress$CaringForPets[102:102]= c("B18") 
Compress$CaringForPets[103:103]= c("B18")
attach(Compress)
CaringForPets

attach(Compress)
GEOACL00
Compress$GEOACL00[14:14]= c("B19") # K2,3 Bipartite 19
Compress$GEOACL00[37:37]= c("B19") 
Compress$GEOACL00[40:40]= c("B19")
Compress$GEOACL00[73:73]= c("B19") 
Compress$GEOACL00[96:96]= c("B19") 
Compress$GEOACL00[99:99]= c("B19")  
attach(Compress)
GEOACL00
attach(Compress)
ShoppingAndServices
Compress$ShoppingAndServices[14:14]= c("B19") # K2,3 Bipartite 19
Compress$ShoppingAndServices[37:37]= c("B19") 
Compress$ShoppingAndServices[40:40]= c("B19")
Compress$ShoppingAndServices[73:73]= c("B19") 
Compress$ShoppingAndServices[96:96]= c("B19") 
Compress$ShoppingAndServices[99:99]= c("B19") 
attach(Compress)
ShoppingAndServices
 
attach(Compress)
GEOACL00
Compress$GEOACL00[6:6]= c("B20") # K2,3 Bipartite 20
Compress$GEOACL00[41:41]= c("B20") 
Compress$GEOACL00[57:57]= c("B20") 
Compress$GEOACL00[65:65]= c("B20") 
Compress$GEOACL00[100:100]= c("B20") 
Compress$GEOACL00[115:115]= c("B20")
attach(Compress)
GEOACL00
attach(Compress)
TeachingReadingAndTalkingWithChild
Compress$TeachingReadingAndTalkingWithChild[6:6]= c("B20") # K2,3 Bipartite 20
Compress$TeachingReadingAndTalkingWithChild[41:41]= c("B20") 
Compress$TeachingReadingAndTalkingWithChild[57:57]= c("B20") 
Compress$TeachingReadingAndTalkingWithChild[65:65]= c("B20") 
Compress$TeachingReadingAndTalkingWithChild[100:100]= c("B20") 
Compress$TeachingReadingAndTalkingWithChild[115:115]= c("B20") 
attach(Compress)
TeachingReadingAndTalkingWithChild

attach(Compress)
GEOACL00
Compress$GEOACL00[7:7]= c("B21") # K2,3 Bipartite 21
Compress$GEOACL00[50:50]= c("B21") 
Compress$GEOACL00[58:58]= c("B21") 
Compress$GEOACL00[66:66]= c("B21") 
Compress$GEOACL00[109:109]= c("B21") 
Compress$GEOACL00[116:116]= c("B21")
attach(Compress)
GEOACL00
attach(Compress)
TeachingReadingAndTalkingWithChild
Compress$TeachingReadingAndTalkingWithChild[7:7]= c("B21") # K2,3 Bipartite21
Compress$TeachingReadingAndTalkingWithChild[50:50]= c("B21") 
Compress$TeachingReadingAndTalkingWithChild[58:58]= c("B21") 
Compress$TeachingReadingAndTalkingWithChild[66:66]= c("B21") 
Compress$TeachingReadingAndTalkingWithChild[109:109]= c("B21") 
Compress$TeachingReadingAndTalkingWithChild[116:116]= c("B21") 
attach(Compress)
TeachingReadingAndTalkingWithChild

attach(Compress)
GEOACL00
Compress$GEOACL00[3:3]= c("B23") # K2,3 Bipartite 22
Compress$GEOACL00[50:50]= c("B23") 
Compress$GEOACL00[54:54]= c("B23")
Compress$GEOACL00[62:62]= c("B23")
Compress$GEOACL00[109:109]= c("B23") 
Compress$GEOACL00[113:113]= c("B23")  
attach(Compress)
GEOACL00
attach(Compress)
SportsAndOutdoorActivitiesExceptWalkingAndHiking
Compress$SportsAndOutdoorActivitiesExceptWalkingAndHiking[3:3]= c("B22") # K2,3 Bipartite 22
Compress$SportsAndOutdoorActivitiesExceptWalkingAndHiking[50:50]= c("B22") 
Compress$SportsAndOutdoorActivitiesExceptWalkingAndHiking[54:54]= c("B22") 
Compress$SportsAndOutdoorActivitiesExceptWalkingAndHiking[62:62]= c("B22")
Compress$SportsAndOutdoorActivitiesExceptWalkingAndHiking[09:109]= c("B22") 
Compress$SportsAndOutdoorActivitiesExceptWalkingAndHiking[113:113]= c("B22")
attach(Compress)
SportsAndOutdoorActivitiesExceptWalkingAndHiking

attach(Compress)
GEOACL00
Compress$GEOACL00[7:7]= c("B23") # K2,3 Bipartite 23
Compress$GEOACL00[47:47]= c("B23") 
Compress$GEOACL00[58:58]= c("B23") 
Compress$GEOACL00[66:66]= c("B23") 
Compress$GEOACL00[106:106]= c("B23") 
Compress$GEOACL00[116:116]= c("B23")
attach(Compress)
GEOACL00
attach(Compress)
HobbiesAndGamesExceptComputingAndComputerGames
Compress$HobbiesAndGamesExceptComputingAndComputerGames[7:7]= c("B23") # K2,3 Bipartite 23
Compress$HobbiesAndGamesExceptComputingAndComputerGames[47:47]= c("B23") 
Compress$HobbiesAndGamesExceptComputingAndComputerGames[58:58]= c("B23") 
Compress$HobbiesAndGamesExceptComputingAndComputerGames[66:66]= c("B23") 
Compress$HobbiesAndGamesExceptComputingAndComputerGames[106:106]= c("B23") 
Compress$HobbiesAndGamesExceptComputingAndComputerGames[116:116]= c("B23") 
attach(Compress)
HobbiesAndGamesExceptComputingAndComputerGames

attach(Compress)
GEOACL00
Compress$GEOACL00[3:3]= c("B24") # K2,3 Bipartite 24
Compress$GEOACL00[46:46]= c("B24") 
Compress$GEOACL00[54:54]= c("B24")
Compress$GEOACL00[62:62]= c("B24") 
Compress$GEOACL00[106:106]= c("B24") 
Compress$GEOACL00[112:112]= c("B24")  
attach(Compress)
GEOACL00
attach(Compress)
RadioAndMusic
Compress$RadioAndMusic[3:3]= c("B24") # K2,3 Bipartite 24
Compress$RadioAndMusic[46:46]= c("B24") 
Compress$RadioAndMusic[54:54]= c("B24")
Compress$RadioAndMusic[62:62]= c("B24") 
Compress$RadioAndMusic[106:106]= c("B24") 
Compress$RadioAndMusic[112:112]= c("B24")  
attach(Compress)
RadioAndMusic

attach(Compress)
GEOACL00
Compress$GEOACL00[40:40]= c("B25") # K2,3 Bipartite 25
Compress$GEOACL00[43:43]= c("B25") 
Compress$GEOACL00[64:64]= c("B25") 
Compress$GEOACL00[96:96]= c("B25") 
Compress$GEOACL00[99:99]= c("B25") 
Compress$GEOACL00[113:113]= c("B25") 
attach(Compress)
GEOACL00
attach(Compress)
UnspecifiedLeisure
Compress$UnspecifiedLeisure[40:40]= c("B25") # K2,3 Bipartite 25
Compress$UnspecifiedLeisure[43:43]= c("B25") 
Compress$UnspecifiedLeisure[64:64]= c("B25") 
Compress$UnspecifiedLeisure[96:96]= c("B25")
Compress$UnspecifiedLeisure[99:99]= c("B25") 
Compress$UnspecifiedLeisure[113:113]= c("B25") 
attach(Compress)
UnspecifiedLeisure

attach(Compress)
GEOACL00
Compress$GEOACL00[4:4]= c("B26") # K2,3 Bipartite 26
Compress$GEOACL00[9:9]= c("B26") 
Compress$GEOACL00[55:55]= c("B26") 
Compress$GEOACL00[63:63]= c("B26") 
Compress$GEOACL00[68:68]= c("B26") 
Compress$GEOACL00[113:113]= c("B26")
attach(Compress)
GEOACL00
attach(Compress)
TravelToFromWork
Compress$TravelToFromWork[4:4]= c("B26") # K2,3 Bipartite 26
Compress$TravelToFromWork[9:9]= c("B26") 
Compress$TravelToFromWork[55:55]= c("B26")
Compress$TravelToFromWork[63:63]= c("B26") 
Compress$TravelToFromWork[68:68]= c("B26") 
Compress$TravelToFromWork[113:113]= c("B26")  
attach(Compress)
TravelToFromWork

attach(Compress)
GEOACL00
Compress$GEOACL00[2:2]= c("B27") # K2,3 Bipartite 27
Compress$GEOACL00[42:42]= c("B27") 
Compress$GEOACL00[53:53]= c("B27") 
Compress$GEOACL00[61:61]= c("B27") 
Compress$GEOACL00[101:101]= c("B27") 
Compress$GEOACL00[111:111]= c("B27")
attach(Compress)
GEOACL00
attach(Compress)
TravelToFromWork
Compress$TravelToFromWork[2:2]= c("B27") # K2,3 Bipartite 27
Compress$TravelToFromWork[42:42]= c("B27") 
Compress$TravelToFromWork[53:53]= c("B27")
Compress$TravelToFromWork[61:61]= c("B27") 
Compress$TravelToFromWork[101:101]= c("B27") 
Compress$TravelToFromWork[111:111]= c("B27")  
attach(Compress28)
TravelToFromWork

attach(Compress)
GEOACL00
Compress$GEOACL00[2:2]= c("B28") # K2,3 Bipartite 28
Compress$GEOACL00[42:42]= c("B28") 
Compress$GEOACL00[53:53]= c("B28") 
Compress$GEOACL00[62:62]= c("B28") 
Compress$GEOACL00[101:101]= c("B28") 
Compress$GEOACL00[111:111]= c("B28") 
attach(Compress)
GEOACL00
attach(Compress)
TravelRelatedToStudy
Compress$TravelRelatedToStudy[2:2]= c("B28") # K2,3 Bipartite 28
Compress$TravelRelatedToStudy[42:42]= c("B28") 
Compress$TravelRelatedToStudy[53:53]= c("B28") 
Compress$TravelRelatedToStudy[62:62]= c("B28")
Compress$TravelRelatedToStudy[101:101]= c("B28") 
Compress$TravelRelatedToStudy[112:112]= c("B28") 
attach(Compress)
TravelRelatedToStudy

attach(Compress)
GEOACL00
Compress$GEOACL00[4:4]= c("B29") # K2,3 Bipartite 29
Compress$GEOACL00[45:45]= c("B29") 
Compress$GEOACL00[55:55]= c("B29") 
Compress$GEOACL00[63:63]= c("B29") 
Compress$GEOACL00[103:103]= c("B29") 
Compress$GEOACL00[113:113]= c("B29") 
attach(Compress30)
GEOACL00
attach(Compress)
TravelRelatedToShoppingAndServices
Compress$TravelRelatedToShoppingAndServices[4:4]= c("B29") # K2,3 Bipartite 29
Compress$TravelRelatedToShoppingAndServices[45:45]= c("B29") 
Compress$TravelRelatedToShoppingAndServices[55:55]= c("B29") 
Compress$TravelRelatedToShoppingAndServices[63:63]= c("B29") 
Compress$TravelRelatedToShoppingAndServices[103:103]= c("B29") 
Compress$TravelRelatedToShoppingAndServices[113:113]= c("B29") 
attach(Compress)
TravelRelatedToShoppingAndServices

attach(Compress)
GEOACL00
Compress$GEOACL00[7:7]= c("B30") # K2,3 Bipartite 30
Compress$GEOACL00[56:56]= c("B30") 
Compress$GEOACL00[58:58]= c("B30")
Compress$GEOACL00[66:66]= c("B30") 
Compress$GEOACL00[114:114]= c("B30") 
Compress$GEOACL00[117:117]= c("B30") 
attach(Compress)
GEOACL00
attach(Compress)
TransportingAChild
Compress$TransportingAChild[7:7]= c("B30") # K2,3 Bipartite 30
Compress$TransportingAChild[56:56]= c("B30") 
Compress$TransportingAChild[58:58]= c("B30") 
Compress$TransportingAChild[66:66]= c("B30") 
Compress$TransportingAChild[114:114]= c("B30") 
Compress$TransportingAChild[117:117]= c("B30") 
attach(Compress)
TransportingAChild

write.csv(Compress, file = "MyData.csv",row.names=T)
CompressBipartite1<- read.csv("MyData.csv", header=T, as.is=T)
CompressBipartite1

#  ================ Tree Layouts after Compress  ================

{
 print(
igraph2 <- graph.data.frame(CompressBipartite1)
igraph2
V(igraph2)$type <- V(igraph2)$name %in% CompressBipartite1[,1]
bipartite.projection(igraph2)
bipartite_mapping(igraph2)
lc <- largest.cliques(igraph2)
lc

# Fruchterman.reingold.layout(Tree layout) 
V(igraph2)$frame.color <- "white"
V(igraph2)$color = "orange"
V(igraph2)$size = 6
E(igraph2)$arrow.mode = 0
plot(igraph2, vertex.label.cex=.1, layout=layout.fruchterman.reingold, main="Tree layout (30 K2, 3 Bipartite)")

end.time <- Sys.time()
time.taken <- end.time - start.time
time.taken
  )
 }
}




