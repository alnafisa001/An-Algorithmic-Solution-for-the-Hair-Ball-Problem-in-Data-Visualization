# ================ Packages ================

#For a Network Analysis and Visualization
#https://cran.r-project.org/web/packages/igraph/index.html
install.packages("igraph", dependencies=TRUE)
library(igraph)

#Tools to create and modify network objects. The network class can represent a range of relational data types, and supports arbitrary vertex/edge/graph attributes.
#https://cran.r-project.org/web/packages/network/index.html
install.packages("network")
library(network)

#Calculates a variety of indices and values for a bipartite network 
#http://www.inside-r.org/packages/cran/bipartite/docs/.networklevel
install.packages("bipartite")
library(bipartite)

#A range of tools for social network analysis, including node and graph-level indices, structural distance and covariance methods, structural equivalence detection, network regression, random graph generation, and 2D/3D network visualization.
#https://cran.r-project.org/web/packages/sna/index.html
install.packages("sna")
library(sna)

#Construct visualizations such as timelines and animated movies of networkDynamic objects to show
changes in structure and attributes over time.
#https://cran.r-project.org/web/packages/ndtv/ndtv.pdf
install.packages("ndtv")
library(ndtv)

#For a sequence of font family names, return the first one installed on the system.
#https://cran.r-project.org/web/packages/extrafont/extrafont.pdf
install.packages("extrafont")
library(extrafont)

#To analysis of bipartite graphs and their monopartite projections
#http://crantastic.org/packages/biGraph
install.packages("biGraph")
library(biGraph)

#Build, Import and Export GEXF Graph Files
#https://cran.r-project.org/web/packages/rgexf/index.html
install.packages("rgexf", dependencies=TRUE)
library(rgexf)

#Tools for Parsing and Generating XML Within R and S-Plus
#https://cran.r-project.org/web/packages/XML/index.html
install.packages("XML", dependencies=TRUE)
library(XML)

#Simple Animated Plots For R
#https://cran.r-project.org/web/packages/anim.plots/index.html
install.packages("anim.plots", dependencies=TRUE)
library(anim.plots)

#linkcomm provides tools for the generation, visualization, and analysis of link communities in networks of arbitrary size and type.
#https://cran.r-project.org/web/packages/linkcomm/index.html
install.packages("linkcomm")
library(linkcomm)

# Simulate Bipartite Graphs with Fixed Marginals Through Sequential Importance Sampling.
# https://cran.r-project.org/web/packages/networksis/index.html
install.packages("networksis")
library("networksis")

# ================ Read the data ================

setwd('C:/Users/Sony/Desktop')
AnAge<- read.csv("AnAge.csv", header=T, as.is=T)
AnAge

#Runtime
start.time <- Sys.time()

attach(AnAge)
CommonName
MaximumLongevityYear
relations<-as.matrix(AnAge)
network.edgecount(nrelations)
nrelations<-network(relations,AnAge=T)
nrelations
nv <- nrow(AnAge)
nv 
net <- network.initialize(nv)
net 
# Data frame of edges
igraph <- graph.data.frame(AnAge)
igraph
V(igraph)$type <- V(igraph)$name %in% AnAge[,1]
bipartite_mapping(igraph)
lc <- getLinkCommunities(AnAge, hcmethod = "single")
sc <- spinglass.community(igraph)
sc

#  ================ Layouts ================

# Random layout
V(igraph)$frame.color <- "white"
V(igraph)$color = "orange"
V(igraph)$size = 8
E(igraph)$arrow.mode = 0
plot(igraph, layout=layout.random, main="Random Layout",vertex.label=c("", rep("", vcount(igraph)-1)))

#Bipartite Package
lc <- getLinkCommunities(AnAge, hcmethod = "single")

# Fruchterman.reingold.layout(Tree layout) 
minC <- rep(-Inf, vcount(igraph))
maxC <- rep(Inf, vcount(igraph))
minC[1] <- maxC[1] <- 0
co <- layout_with_fr(igraph, minx=minC, maxx=maxC,miny=minC, maxy=maxC)
co[1,]
plot(igraph, layout=co, vertex.size=70, edge.arrow.size=0.2,
     vertex.label=c("", rep("", vcount(igraph)-1)), rescale=FALSE,
     xlim=range(co[,1]), ylim=range(co[,2]), vertex.label.dist=0,
     vertex.label.color="red",main="Tree layout (No K2, 3 Bipartite)")

end.time <- Sys.time()
time.taken <- end.time - start.time
time.taken





