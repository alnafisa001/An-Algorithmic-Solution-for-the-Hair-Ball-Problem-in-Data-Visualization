# ================ Packages ================

#For a Network Analysis and Visualization
#https://cran.r-project.org/web/packages/igraph/index.html
install.packages("igraph", dependencies=TRUE)
library(igraph)

#Tools to create and modify network objects. The network class can represent a range of relational data types, and supports arbitrary vertex/edge/graph attributes.
#https://cran.r-project.org/web/packages/network/index.html
install.packages("network")
library(network)

#Calculates a variety of indices and values for a bipartite network 
#http://www.inside-r.org/packages/cran/bipartite/docs/.networklevel
install.packages("bipartite")
library(bipartite)

#A range of tools for social network analysis, including node and graph-level indices, structural distance and covariance methods, structural equivalence detection, network regression, random graph generation, and 2D/3D network visualization.
#https://cran.r-project.org/web/packages/sna/index.html
install.packages("sna")
library(sna)

#Construct visualizations such as timelines and animated movies of networkDynamic objects to show
changes in structure and attributes over time.
#https://cran.r-project.org/web/packages/ndtv/ndtv.pdf
install.packages("ndtv")
library(ndtv)

#For a sequence of font family names, return the first one installed on the system.
#https://cran.r-project.org/web/packages/extrafont/extrafont.pdf
install.packages("extrafont")
library(extrafont)

#To analysis of bipartite graphs and their monopartite projections
#http://crantastic.org/packages/biGraph
install.packages("biGraph")
library(biGraph)

#Build, Import and Export GEXF Graph Files
#https://cran.r-project.org/web/packages/rgexf/index.html
install.packages("rgexf", dependencies=TRUE)
library(rgexf)

#Tools for Parsing and Generating XML Within R and S-Plus
#https://cran.r-project.org/web/packages/XML/index.html
install.packages("XML", dependencies=TRUE)
library(XML)

#Simple Animated Plots For R
#https://cran.r-project.org/web/packages/anim.plots/index.html
install.packages("anim.plots", dependencies=TRUE)
library(anim.plots)

#linkcomm provides tools for the generation, visualization, and analysis of link communities in networks of arbitrary size and type.
#https://cran.r-project.org/web/packages/linkcomm/index.html
install.packages("linkcomm")
library(linkcomm)

# Simulate Bipartite Graphs with Fixed Marginals Through Sequential Importance Sampling.
# https://cran.r-project.org/web/packages/networksis/index.html
install.packages("networksis")
library("networksis")

# ================ Read the data ================

setwd('C:/Users/Sony/Desktop')
Media<- read.csv("BigDataset-Media-EDGES.csv", header=T, as.is=T)
Media

#Runtime
start.time <- Sys.time()

attach(Media)
from 
to
nrelations <-as.matrix(Media)
network.edgecount(nrelations)
nrelations <-network(relations,anage=T)
nrelations
nv <- nrow(Media)
nv 
net <- network.initialize(nv)
net 
# Data frame of edges
igraph1 <- graph.data.frame(Media)
igraph1
V(igraph1)$type <- V(igraph1)$name %in% Media[,1]
bipartite_mapping(igraph1)
lc <- getLinkCommunities(Media, hcmethod = "single")
#sc <- spinglass.community(igraph1)
#sc

V(igraph1)$frame.color <- "white"
V(igraph1)$color = "orange"
V(igraph1)$size = 13
E(igraph1)$arrow.mode = 0
#tkid is the id of the tkplot that will open
#tkid <- tkplot(igraph1)
#plot(igraph1)

#  ================ Loop for Five K2,3 Bipartite ================

for(igraph in data.frame(Media)){ 
if (
lc <- largest.cliques(igraph1)
lc

# K2,3 Bipartite 1
c1 = from[c(1,2,3,4,5,6)]
n1 = unique(c1)
c2 = to[c(1,2,3,4,5,6)]
n2 = unique(c2)
b1 = capture.output(cat(n1,n2))
cat(b1,"\n")

# K2,3 Bipartite 2
data.frame(Media)
c3 = from[c(7,8,9,10,11,12)]
n3 = unique(c3)
c4 = to[c(7,8,9,10,11,12)]
n4 = unique(c4)
b2 = capture.output(cat(n3,n4))
cat(b2,"\n")

# K2,3 Bipartite 3
data.frame(Media)
c5 = from[c(19,20,21,22,23,24)]
n5 = unique(c5)
c6 = to[c(19,20,21,22,23,24)]
n6 = unique(c6)
b3 = capture.output(cat(n5,n6))
cat(b3,"\n")

# K2,3 Bipartite 4
data.frame(Media)
c7 = from[c(25,26,27,28,29,30)]
n7 = unique(c7)
c8 = to[c(25,26,27,28,29,30)]
n8 = unique(c8)
b4 = capture.output(cat(n7,n8))
cat(b4,"\n")

# K2,3 Bipartite 5
data.frame(Media)
c9 = from[c(37,38,39,40,41,42)]
n9 = unique(c9)
c10 = to[c(37,38,39,40,41,42)]
n10 = unique(c10)
b5 = capture.output(cat(n9,n10))
cat(b5,"\n")

# K2,3 Bipartite 6
data.frame(Media)
c11 = from[c(43,44,45,46,47,48)]
n11 = unique(c11)
c12 = to[c(43,44,45,46,47,48)]
n12 = unique(c12)
b6 = capture.output(cat(n11,n12))
cat(b6,"\n")

# K2,3 Bipartite 7
data.frame(Media)
c13 = from[c(49,50,51,52,53,54)]
n13 = unique(c13)
c14 = to[c(49,50,51,52,53,54)]
n14 = unique(c14)
b7 = capture.output(cat(n13,n14))
cat(b7,"\n")

# K2,3 Bipartite 8
data.frame(Media)
c15 = from[c(55,56,57,58,59,60)]
n15 = unique(c15)
c16 = to[c(55,56,57,58,59,60)]
n16 = unique(c16)
b8 = capture.output(cat(n15,n16))
cat(b8,"\n")

# K2,3 Bipartite 9
data.frame(Media)
c17 = from[c(65,66,67,68,69,70)]
n17 = unique(c17)
c18 = to[c(65,66,67,68,69,70)]
n18 = unique(c18)
b9 = capture.output(cat(n17,n18))
cat(b9,"\n")

# K2,3 Bipartite 10
data.frame(Media)
c19 = from[c(71,72,73,74,75,76)]
n19 = unique(c19)
c20 = to[c(71,72,73,74,75,76)]
n20 = unique(c20)
b10 = capture.output(cat(n19,n20))
cat(b10,"\n")

# K2,3 Bipartite 11
data.frame(Media)
c21 = from[c(77,78,79,80,81,82)]
n21 = unique(c21)
c22 = to[c(77,78,79,80,81,82)]
n22 = unique(c22)
b11 = capture.output(cat(n21,n22))
cat(b11,"\n")

# K2,3 Bipartite 12
data.frame(Media)
c23 = from[c(83,84,85,86,87,88)]
n23 = unique(c23)
c24 = to[c(83,84,85,86,87,88)]
n24 = unique(c24)
b12 = capture.output(cat(n23,n24))
cat(b12,"\n")

# K2,3 Bipartite 13
data.frame(Media)
c25 = from[c(89,90,91,92,93,94)]
n25 = unique(c25)
c26 = to[c(89,90,91,92,93,94)]
n26 = unique(c26)
b13 = capture.output(cat(n25,n26))
cat(b13,"\n")

# K2,3 Bipartite 14
data.frame(Media)
c27 = from[c(95,96,97,98,99,100)]
n27 = unique(c27)
c28 = to[c(95,96,97,98,99,100)]
n28 = unique(c28)
b14 = capture.output(cat(n27,n28))
cat(b14,"\n")

# K2,3 Bipartite Between All_1
data.frame(Media)
c29 = from[c(13,14,15,16,17,18)]
n29 = unique(c29)
c30 = to[c(13,14,15,16,17,18)]
n30 = unique(c30)
bBA_1 = capture.output(cat(n29,n30))
cat(bBA_1,"\n")

# K2,3 Bipartite Between All_2
data.frame(Media)
c31 = from[c(31,32,33,34,35,36)]
n31 = unique(c11)
c32 = to[c(31,32,33,34,35,36)]
n32 = unique(c12)
bBA_2 = capture.output(cat(n31,n32))
cat(bBA_2,"\n")

AllBipartiteK23 = capture.output(cat(n1,n2,n3,n4,n5,n6,n7,n8,n9,n10,n11,n12))
AllBipartiteK23
cat(AllBipartiteK23,"\n")
lc <- largest.cliques(igraph1)
lc
#sgc <- spinglass.community(igraph)
#sgc 

#  ================ First Layouts ================

{
    print(
# Random layout
V(igraph1)$frame.color <- "white"
V(igraph1)$color = "orange"
V(igraph1)$size = 11
E(igraph1)$arrow.mode = 0
plot(igraph1, layout=layout.random, main="Random Layout",vertex.label.cex=.4)

#Bipartite Package 
lc <- getLinkCommunities(Media, hcmethod = "single")
plot(igraph1, vertex.size=15, layout=layout.bipartite, vertex.label=V(igraph1)$media, vertex.label.cex=.9, main="Bipartite K2, 3 Layout")

# Fruchterman.reingold.layout(Tree layout) 
V(igraph1)$frame.color <- "white"
V(igraph1)$color = "orange"
V(igraph1)$size = 7.5
E(igraph1)$arrow.mode = 0
plot(igraph1, layout=layout.fruchterman.reingold, main="Tree layout (14 K2, 3 Bipartite)", vertex.label=c("", rep("", vcount(igraph1)-1)))

#end.time <- Sys.time()
#time.taken <- end.time - start.time
#time.taken

#  ================ First Compress of Every K2,3 Bipartite ================

 else(

#Runtime
#start.time <- Sys.time()

Compress1 <- data.frame(Media)
Compress1 
attach(Compress1)
Compress1$from[1:3]= c("B1") # K2,3 Bipartite 1
Compress1$from[4:6]= c("B1") 
Compress1$from[7:9]= c("B2") # K2,3 Bipartite 2
Compress1$from[10:12]= c("B2") 
Compress1$from[13:15]= c("B1") # K2,3 Bipartite Between All_1
Compress1$from[16:18]= c("B2") 
Compress1$from[19:21]= c("B3") # K2,3 Bipartite 3
Compress1$from[22:24]= c("B3") 
Compress1$from[25:27]= c("B4") # K2,3 Bipartite 4
Compress1$from[28:30]= c("B4")
Compress1$from[31:33]= c("B6") # K2,3 Bipartite Between All_2
Compress1$from[34:36]= c("B7")
Compress1$from[37:39]= c("B5") # K2,3 Bipartite 5
Compress1$from[40:42]= c("B5") 
Compress1$from[43:45]= c("B6") # K2,3 Bipartite 6
Compress1$from[46:48]= c("B6") 
Compress1$from[49:51]= c("B7") # K2,3 Bipartite 7
Compress1$from[52:54]= c("B7") 
Compress1$from[55:57]= c("B8") # K2,3 Bipartite 8
Compress1$from[58:60]= c("B8") 
Compress1$from[65:67]= c("B9") # K2,3 Bipartite 9
Compress1$from[68:70]= c("B9") 
Compress1$from[71:73]= c("B10") # K2,3 Bipartite 10
Compress1$from[74:76]= c("B10") 
Compress1$from[77:79]= c("B11") # K2,3 Bipartite 11
Compress1$from[80:82]= c("B11") 
Compress1$from[83:85]= c("B12") # K2,3 Bipartite 12
Compress1$from[86:88]= c("B12") 
Compress1$from[89:91]= c("B13") # K2,3 Bipartite 13
Compress1$from[92:94]= c("B13") 
Compress1$from[95:97]= c("B14") # K2,3 Bipartite 14
Compress1$from[98:100]= c("B14") 
attach(Compress1)
from

Compress1$to[1:3]= c("B1") # K2,3 Bipartite 1
Compress1$to[4:6]= c("B1") 
Compress1$to[7:9]= c("B2") # K2,3 Bipartite 2
Compress1$to[10:12]= c("B2") 
Compress1$to[13:13]= c("B3") # K2,3 Bipartite Between All_1
Compress1$to[14:14]= c("B4")
Compress1$to[15:15]= c("B5")
Compress1$to[16:16]= c("B3")
Compress1$to[17:17]= c("B4")
Compress1$to[18:18]= c("B5")
Compress1$to[19:21]= c("B3") # K2,3 Bipartite 3
Compress1$to[22:24]= c("B3") 
Compress1$to[25:27]= c("B4") # K2,3 Bipartite 4
Compress1$to[28:30]= c("B4")
Compress1$to[31:31]= c("B8") # K2,3 Bipartite Between All_2
Compress1$to[32:32]= c("B9")
Compress1$to[33:33]= c("B10")
Compress1$to[34:34]= c("B8")
Compress1$to[35:35]= c("B9")
Compress1$to[36:36]= c("B10")
Compress1$to[37:39]= c("B5") # K2,3 Bipartite 5
Compress1$to[40:42]= c("B5") 
Compress1$to[43:45]= c("B6") # K2,3 Bipartite 6
Compress1$to[46:48]= c("B6") 
Compress1$to[49:51]= c("B7") # K2,3 Bipartite 7
Compress1$to[52:54]= c("B7") 
Compress1$to[55:57]= c("B8") # K2,3 Bipartite 8
Compress1$to[58:60]= c("B8") 
Compress1$to[65:67]= c("B9") # K2,3 Bipartite 9
Compress1$to[68:70]= c("B9") 
Compress1$to[71:73]= c("B10") # K2,3 Bipartite 10
Compress1$to[74:76]= c("B10") 
Compress1$to[77:79]= c("B11") # K2,3 Bipartite 11
Compress1$to[80:81]= c("B11") 
Compress1$to[82:82]= c("B12") 
Compress1$to[83:85]= c("B12") # K2,3 Bipartite 12
Compress1$to[86:87]= c("B12")
Compress1$to[88:88]= c("B13")  
Compress1$to[89:91]= c("B13") # K2,3 Bipartite 13
Compress1$to[92:93]= c("B13") 
Compress1$to[94:94]= c("B14") 
Compress1$to[95:97]= c("B14") # K2,3 Bipartite 14
Compress1$to[98:99]= c("B14")
Compress1$to[100:100]= c("B11")
attach(Compress1)
to

attach(Compress1)
Compress1
write.csv(Compress1, file = "MyData.csv",row.names=FALSE)
CompressBipartite1<- read.csv("MyData.csv", header=T, as.is=T)
CompressBipartite1

igraph2 <- graph.data.frame(CompressBipartite1)
igraph2
V(igraph2)$type <- V(igraph2)$name %in% CompressBipartite1[,1]
bipartite.projection(igraph2)
bipartite_mapping(igraph2)
lc <- largest.cliques(igraph2)
lc
lc <- getLinkCommunities(CompressBipartite1, hcmethod = "single")

#  ================ Second Layouts ================

{
 print(

#Bipartite layout
lc <- getLinkCommunities(CompressBipartite1, hcmethod = "single")

# Fruchterman.reingold.layout(Tree layout) 
V(igraph2)$frame.color <- "white"
V(igraph2)$color = "orange"
V(igraph2)$size = 11
E(igraph2)$arrow.mode = 0
plot(igraph2, vertex.label.cex=.4, layout=layout.fruchterman.reingold, mark.groups=list(c("B1"),c("B2"),c("B3"),c("B4"),c("B5"),c("B6"),c("B7"),c("B8"),c("B9"),c("B10"),c("B11"),c("B12"),c("B13"),c("B14")),mark.col=c("green","red", "yellow", "blue", "orange", "cyan", "fireBrick", "black", "brown", "magenta", "tomato", "pink", "salmon", "purple"),main="Tree layout (14 K2, 3 Bipartite)")
legend(x=-1.5, y=-1.1, c("K2,3 Bipartite-1"), pch=21, col="#777777", pt.cex=2, cex=.8, bty="n", ncol=1, pt.bg="green")
legend(x=-1.5, y=-1.2, c("K2,3 Bipartite-2"), pch=21, col="#777777", pt.cex=2, cex=.8, bty="n", ncol=1, pt.bg="red")
legend(x=-1.5, y=-1.3, c("K2,3 Bipartite-3"), pch=21, col="#777777", pt.cex=2, cex=.8, bty="n", ncol=1, pt.bg="yellow")
legend(x=-1.5, y=-1.4, c("."), pch=21, col="#777777", pt.cex=2, cex=.8, bty="n", ncol=1, pt.bg="white")
legend(x=-1.5, y=-1.5, c("."), pch=21, col="#777777", pt.cex=2, cex=.8, bty="n", ncol=1, pt.bg="white")
legend(x=-1.5, y=-1.6, c("K2,3 Bipartite-14"), pch=21, col="#777777", pt.cex=2, cex=.8, bty="n", ncol=1, pt.bg="purple")

)

#  ================ Second Compress of K2,3 Bipartite ================

 else (
Compress2 <- data.frame(CompressBipartite1)
Compress2 
attach(Compress2)
Compress2$from[1:30]= c("All_1")
Compress2$from[37:42]= c("All_1")
Compress2$from[31:36]= c("All_2")
Compress2$from[43:60]= c("All_2")
Compress2$from[65:76]= c("All_2")
attach(Compress2)
from
Compress2$to[1:30]= c("All_1")
Compress2$to[37:42]= c("All_1")
Compress2$to[31:36]= c("All_2")
Compress2$to[43:60]= c("All_2")
Compress2$to[65:76]= c("All_2")
attach(Compress2)
to
attach(Compress2)
Compress2 
write.csv(Compress2, file = "MyData.csv",row.names=FALSE)
CompressBipartite2<- read.csv("MyData.csv", header=T, as.is=T)
CompressBipartite2

igraph3 <- graph.data.frame(CompressBipartite2)
igraph3
V(igraph3)$type <- V(igraph3)$name %in% Compress2[,1]
bipartite.projection(igraph3)
bipartite_mapping(igraph3)
lc <- getLinkCommunities(CompressBipartite2, hcmethod = "single")

#  ================ Third Layouts ================

    print(
#Runtime
#start.time <- Sys.time()

#Bipartite Package 
lc <- getLinkCommunities(CompressBipartite2, hcmethod = "single")
plot(igraph3,vertex.size=15, layout=layout.bipartite, mark.groups=list(c("All_1"),c("All_2")),mark.col=c("green","red"), layout=layout.circle, vertex.label=V(igraph3)$media, vertex.label.cex=.7,  main="Bipartite K2, 3 Layout") 
legend(x=-1.5, y=-1.1, c("K2,3 Bipartite-All"), pch=21,col="green", pt.cex=2, cex=.8, bty="n", ncol=1, pt.bg="green")
legend(x=-1.5, y=-1, c("K2,3 Bipartite-All"), pch=21,col="red", pt.cex=2, cex=.8, bty="n", ncol=1, pt.bg="red")

# Fruchterman Reingold Layou(Tree Layou)
V(igraph3)$frame.color <- "white"
V(igraph3)$color = "orange"
V(igraph3)$size = 11
E(igraph2)$arrow.mode = 0
plot(igraph3, vertex.label.cex=.4, layout=layout.fruchterman.reingold, mark.groups=list(c("All_1"),c("All_2"),c("B11"),c("B12"),c("B13"),c("B14")),mark.col=c("green","red","tomato", "pink", "salmon", "purple"), main="Tree layout (14 K2, 3 Bipartite")
legend(x=-1.5, y=-1.1, c("Five K2,3 in one K2,3 (B1-B5)"), pch=21, col="#777777", pt.cex=2, cex=.8, bty="n", ncol=1, pt.bg="green")
legend(x=-1.5, y=-1.2, c("Five K2,3 in one K2,3 (B6-B10)"), pch=21, col="#777777", pt.cex=2, cex=.8, bty="n", ncol=1, pt.bg="red")
legend(x=-1.5, y=-1.3, c("K2,3 Bipartite-B11"), pch=21, col="#777777", pt.cex=2, cex=.8, bty="n", ncol=1, pt.bg="tomato")
legend(x=-1.5, y=-1.4, c("K2,3 Bipartite-B12"), pch=21, col="#777777", pt.cex=2, cex=.8, bty="n", ncol=1, pt.bg="pink")
legend(x=-1.5, y=-1.5, c("K2,3 Bipartite-B13"), pch=21, col="#777777", pt.cex=2, cex=.8, bty="n", ncol=1, pt.bg="salmon")
legend(x=-1.5, y=-1.6, c("K2,3 Bipartite-B14"), pch=21, col="#777777", pt.cex=2, cex=.8, bty="n", ncol=1, pt.bg="purple")

  )
 }
}
end.time <- Sys.time()
time.taken <- end.time - start.time
time.taken



